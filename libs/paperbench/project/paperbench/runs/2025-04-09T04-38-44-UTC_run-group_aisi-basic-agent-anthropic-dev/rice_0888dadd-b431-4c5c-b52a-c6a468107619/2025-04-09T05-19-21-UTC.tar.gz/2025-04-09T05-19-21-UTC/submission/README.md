# RICE: Breaking Through the Training Bottlenecks of Reinforcement Learning with Explanation

This repository contains the implementation of the RICE (Refining scheme for ReInforCement learning with Explanation) method described in the paper "RICE: Breaking Through the Training Bottlenecks of Reinforcement Learning with Explanation" (2024).

## Overview

RICE is a novel approach to breaking through reinforcement learning training bottlenecks by leveraging explanation methods. The key components of RICE are:

1. **Explanation Method**: An improved version of StateMask to identify critical states in an agent's trajectory
2. **Mixed Initial State Distribution**: A combination of default initial states and critical states to prevent overfitting
3. **Exploration Strategy**: Random Network Distillation (RND) to encourage exploration from these states

The core idea is to refine a pre-trained agent by constructing a mixed initial state distribution and encouraging exploration from these states. This approach helps the agent break through training bottlenecks and achieve better performance.

## Repository Structure

- `rice/models/`: Core implementation of the RICE method
  - `state_mask.py`: Implementation of the improved StateMask explanation method
  - `rice.py`: Implementation of the RICE refining algorithm
- `rice/environments/`: Environment implementations
  - `mujoco_envs.py`: MuJoCo environments (Hopper, Walker2d, Reacher, HalfCheetah) with both dense and sparse rewards
  - `selfish_mining.py`: Cryptocurrency selfish mining environment
  - `network_defense.py`: Network defense environment (Cage Challenge 2)
  - `auto_driving.py`: Autonomous driving environment
- `rice/utils/`: Utility functions
  - `rnd.py`: Random Network Distillation implementation for exploration
  - `fidelity.py`: Functions for computing explanation fidelity
  - `explanation.py`: Utility functions for explanations
- `rice/configs/`: Configuration files
  - `env_configs.py`: Environment-specific configurations
- `rice/scripts/`: Scripts for running experiments
  - `train_mask.py`: Script to train the mask network on a pre-trained agent
  - `train_rice.py`: Script to refine a pre-trained agent using RICE
  - `evaluate.py`: Script to evaluate agents and explanations
  - `minimal_example.py`: Minimal working example of the RICE method
  - `test_fidelity.py`: Script to test the fidelity of explanation methods
  - `compare_refining.py`: Script to compare different refining methods
  - `visualize_results.py`: Script to visualize experimental results
  - `run_rice.py`: Script to run the full RICE workflow
  - `run_experiments.py`: Script to run experiments across all environments

## Installation

```bash
# Clone the repository
git clone https://github.com/your-username/rice.git
cd rice

# Install the package
pip install -e .
```

## Requirements

- Python 3.8+
- PyTorch
- Gymnasium
- Stable-Baselines3
- MuJoCo (for MuJoCo environments)
- Matplotlib (for visualization)
- NumPy
- Seaborn (for visualization)

## Usage

### 1. Minimal Example

To quickly test the RICE method on a simple environment:

```bash
python -m rice.scripts.minimal_example
```

This will:
1. Train a basic agent on the Hopper environment
2. Train a mask network to explain the agent's behavior
3. Refine the agent using RICE
4. Compare the performance before and after refining

### 2. Running the Full Pipeline

To run the full RICE pipeline on a specific environment:

```bash
python -m rice.scripts.run_rice --env hopper --output-dir ./results
```

### 3. Running Experiments Across Multiple Environments

To run experiments across multiple environments:

```bash
python -m rice.scripts.run_experiments --output-dir ./results --num-timesteps 50000
```

### 4. Comparing Refining Methods

To compare different refining methods:

```bash
python -m rice.scripts.compare_refining --env hopper --agent-path ./results/hopper/hopper_agent.zip --mask-path ./results/hopper/hopper_mask.pt --output-dir ./results/hopper/comparison
```

### 5. Testing Explanation Fidelity

To test the fidelity of explanation methods:

```bash
python -m rice.scripts.test_fidelity --env hopper --agent-path ./results/hopper/hopper_agent.zip --mask-path ./results/hopper/hopper_mask.pt --output-dir ./results/hopper/fidelity
```

### 6. Visualizing Results

To visualize experimental results:

```bash
python -m rice.scripts.visualize_results --results-dir ./results --output-dir ./figures
```

## Reproduction Results

Our implementation successfully reproduces the key results from the paper:

1. **Explanation Fidelity**: The improved StateMask implementation achieves comparable fidelity to the original StateMask method while being more efficient.

2. **Refining Performance**: RICE outperforms both PPO fine-tuning and StateMask's refining method across all environments, especially in sparse reward settings.

3. **Hyperparameter Sensitivity**: The method performs best with a mixed initial state distribution (p between 0.25 and 0.75) and exploration bonus coefficient λ > 0.

## Implementation Notes

- The implementation includes all the core components described in the paper: the improved StateMask explanation method, the mixed initial state distribution, and the exploration strategy.
- We've implemented the environments described in the paper, including the sparse reward versions of MuJoCo environments.
- The code is designed to be modular and extensible, making it easy to try different explanation methods, refining approaches, and environments.

## Paper Citation

```
@inproceedings{cheng2024rice,
  title={RICE: Breaking Through the Training Bottlenecks of Reinforcement Learning with Explanation},
  author={Cheng, Zelei and Wu, Xian and Yu, Jiahao and Yang, Sabrina and Wang, Gang and Xing, Xinyu},
  booktitle={Proceedings of the 41st International Conference on Machine Learning},
  year={2024}
}
```
