# RICE Documentation

This documentation provides a comprehensive guide to the RICE (Refining scheme for ReInforCement learning with Explanation) implementation.

## Overview

RICE is a novel approach to refining reinforcement learning agents that have hit training bottlenecks. The method leverages explanation techniques to identify critical states in an agent's trajectory and then constructs a mixed initial state distribution combining both default initial states and these critical states. This approach helps the agent break through training bottlenecks through exploration.

## Core Components

RICE consists of three main components:

1. **Explanation Method**: An improved version of StateMask to identify critical states
2. **Mixed Initial State Distribution**: A combination of default initial states and critical states to prevent overfitting
3. **Exploration Strategy**: Random Network Distillation (RND) to encourage exploration from these states

## Directory Structure

```
rice/
├── models/              # Core models
│   ├── state_mask.py    # Improved StateMask implementation
│   └── rice.py          # RICE algorithm implementation
├── environments/        # Environment implementations
│   ├── mujoco_envs.py   # MuJoCo environments
│   ├── selfish_mining.py # Cryptocurrency mining environment
│   ├── network_defense.py # Network defense environment
│   └── auto_driving.py  # Autonomous driving environment
├── utils/               # Utility functions
│   ├── fidelity.py      # Fidelity score calculation
│   ├── explanation.py   # Explanation utility functions
│   └── rnd.py           # Random Network Distillation
├── configs/             # Configuration files
│   └── env_configs.py   # Environment-specific configurations
└── scripts/             # Training and evaluation scripts
    ├── train_mask.py    # Script to train the mask network
    ├── train_rice.py    # Script to train with RICE
    ├── evaluate.py      # Evaluation script
    └── ...              # Additional scripts
```

## Getting Started

To get started with RICE, see the [README.md](../README.md) file for installation instructions and basic usage examples.

## Component Documentation

For detailed documentation on each component, see the following files:

- [Models Documentation](models/README.md): Details of the mask network and RICE algorithm
- [Environments Documentation](environments/README.md): Details of the implemented environments
- [Utilities Documentation](utils/README.md): Details of utility functions for explanation and exploration

## Paper Reference

For more details on the theoretical background and performance analysis, please refer to the original paper:

```
Cheng, Z., Wu, X., Yu, J., Yang, S., Wang, G., & Xing, X. (2024). 
RICE: Breaking Through the Training Bottlenecks of Reinforcement Learning with Explanation. 
Proceedings of the 41st International Conference on Machine Learning.
```
