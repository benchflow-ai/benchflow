# Reproducing Key Results from the Paper

This guide provides step-by-step instructions for reproducing the key results from the paper "RICE: Breaking Through the Training Bottlenecks of Reinforcement Learning with Explanation" (2024).

## Overview of Results to Reproduce

The key results from the paper include:

1. **Explanation Fidelity Comparison** (Figure 5): Comparing the fidelity of our improved StateMask with the random baseline
2. **Refining Performance** (Figure 2): Comparing the performance of different refining methods on sparse reward environments
3. **Hyperparameter Sensitivity** (Figures 7-8): Analyzing the impact of hyperparameters on RICE's performance
4. **Performance Comparison Across Environments** (Table 1): Comparing RICE with other refining methods across all environments

## Prerequisites

Before starting, ensure you have installed the RICE package and all dependencies:

```bash
# Install dependencies
pip install -r requirements.txt

# Install the RICE package
pip install -e .
```

## Step 1: Train Base Agents

First, we need to train base agents for each environment. These will serve as the starting point for all refining methods.

```bash
# Train agent for Hopper environment
python -m rice.scripts.train_agent --env hopper --timesteps 1000000 --output-dir ./results/base_agents

# Train agent for Walker2d environment
python -m rice.scripts.train_agent --env walker2d --timesteps 1000000 --output-dir ./results/base_agents

# Train agent for sparse environments
python -m rice.scripts.train_agent --env sparse_hopper --timesteps 1500000 --output-dir ./results/base_agents
python -m rice.scripts.train_agent --env sparse_walker2d --timesteps 1500000 --output-dir ./results/base_agents
```

Alternatively, you can use the provided Makefile command to train all base agents:

```bash
make train_base_agents
```

## Step 2: Train Mask Networks

Next, we need to train mask networks for each base agent to generate explanations.

```bash
# Train mask network for Hopper
python -m rice.scripts.train_mask --env hopper --agent-path ./results/base_agents/hopper_agent.zip --mask-save-path ./results/mask_networks --mask-bonus 0.01

# Train mask network for sparse environments
python -m rice.scripts.train_mask --env sparse_hopper --agent-path ./results/base_agents/sparse_hopper_agent.zip --mask-save-path ./results/mask_networks --mask-bonus 0.01
```

Or use the Makefile command:

```bash
make train_mask_networks
```

## Step 3: Compare Explanation Fidelity

To reproduce the fidelity comparison results (Figure 5), run:

```bash
python -m rice.scripts.test_fidelity --env hopper --agent-path ./results/base_agents/hopper_agent.zip --mask-path ./results/mask_networks/hopper_mask.pt --output-dir ./results/fidelity_results
```

This will evaluate the fidelity of our mask network against a random baseline and generate plots similar to Figure 5 in the paper.

## Step 4: Compare Refining Methods

To reproduce the refining performance comparison (Figure 2), run:

```bash
# Compare refining methods on sparse environments
python -m rice.scripts.compare_refining --env sparse_hopper --agent-path ./results/base_agents/sparse_hopper_agent.zip --mask-path ./results/mask_networks/sparse_hopper_mask.pt --output-dir ./results/refining_comparison
```

This will compare our RICE method with PPO fine-tuning, JSRL, and StateMask-R, and generate plots similar to Figure 2 in the paper.

## Step 5: Analyze Hyperparameter Sensitivity

To reproduce the hyperparameter sensitivity analysis (Figures 7-8), run:

```bash
# Analyze sensitivity to λ (exploration coefficient)
python -m rice.scripts.tune_hyperparameters --env hopper --agent-path ./results/base_agents/hopper_agent.zip --mask-path ./results/mask_networks/hopper_mask.pt --reset-prob 0.5 --exploration-coefs 0,0.001,0.01,0.1 --output-dir ./results/hyperparameter_sensitivity

# Analyze sensitivity to p (reset probability)
python -m rice.scripts.tune_hyperparameters --env hopper --agent-path ./results/base_agents/hopper_agent.zip --mask-path ./results/mask_networks/hopper_mask.pt --exploration-coef 0.01 --reset-probs 0,0.25,0.5,0.75,1.0 --output-dir ./results/hyperparameter_sensitivity
```

## Step 6: Generate Performance Comparison Table

To reproduce the performance comparison across all environments (Table 1), run:

```bash
# Run RICE on all environments first (this may take a while)
python -m rice.scripts.run_experiments --output-dir ./results --num-timesteps 100000

# Generate Table 1
python -m rice.scripts.generate_table --results-dir ./results --output-dir ./table_results
```

This will generate a LaTeX table similar to Table 1 in the paper, as well as visualizations of the performance comparison.

## Step 7: Analyze and Visualize Results

To generate all visualizations from the experimental results, run:

```bash
python -m rice.scripts.visualize_results --results-dir ./results --output-dir ./figures
```

This will create visualizations similar to those in the paper, allowing for visual comparison of the reproduced results with the original paper.

## Troubleshooting

If you encounter issues with the reproduction:

1. Check that all dependencies are correctly installed
2. Ensure that the environments are properly set up
3. Check the logs for specific error messages
4. For MuJoCo environments, ensure that MuJoCo is properly installed

For further assistance, please open an issue on the GitHub repository.
