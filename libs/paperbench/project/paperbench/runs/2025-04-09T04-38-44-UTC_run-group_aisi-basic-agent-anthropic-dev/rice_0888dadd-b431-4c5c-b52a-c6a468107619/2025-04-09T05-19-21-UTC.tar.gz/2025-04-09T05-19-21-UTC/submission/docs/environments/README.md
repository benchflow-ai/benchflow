# Environments Documentation

This document provides detailed documentation for the environments in the RICE implementation.

## MuJoCo Environments

The `mujoco_envs.py` file contains implementations of MuJoCo environments with both dense and sparse rewards.

### Standard MuJoCo Environments

The following standard MuJoCo environments are supported:

- **Hopper** (`hopper`): A 2D robot that hops forward
- **Walker2d** (`walker2d`): A 2D biped robot that walks forward
- **Reacher** (`reacher`): A 2D robot arm that reaches for a target
- **HalfCheetah** (`halfcheetah`): A 2D cheetah robot that runs forward

### Sparse Reward Environments

The sparse reward versions of the MuJoCo environments provide a much more challenging learning problem. In sparse reward environments, the agent receives a reward of +1 only when a certain threshold of progress is reached, and 0 otherwise.

Supported sparse environments:

- **SparseHopper** (`sparse_hopper`)
- **SparseWalker2d** (`sparse_walker2d`)
- **SparseHalfCheetah** (`sparse_halfcheetah`)

### SparseRewardWrapper

```python
class SparseRewardWrapper(gym.Wrapper)
```

The `SparseRewardWrapper` transforms dense rewards to sparse rewards based on a threshold. The agent receives a reward of +1 if it exceeds the threshold, and 0 otherwise.

#### Key Parameters

- `env`: The environment to wrap
- `threshold`: The threshold for sparse rewards

## Selfish Mining Environment

The `selfish_mining.py` file contains an implementation of a cryptocurrency selfish mining environment.

### SelfishMiningEnv

```python
class SelfishMiningEnv(gym.Env)
```

In the selfish mining environment, a miner can choose to either mine on the public chain or keep their blocks private. The goal is to maximize the proportion of blocks in the final blockchain.

#### Key Parameters

- `max_steps`: Maximum number of steps per episode
- `alpha`: The computational power of the selfish miner
- `gamma`: The fraction of honest miners that mine on the selfish chain when a tie occurs

#### State Space

The state space is a 3-dimensional vector:
- `lead`: Difference between private and public chain lengths
- `fork`: Whether a fork exists (0 or 1)
- `next_to_reveal`: Number of blocks to be revealed next

#### Action Space

The action space is discrete with 2 actions:
- `0`: Adopt (mine on the public chain)
- `1`: Override (mine on the private chain)

## Network Defense Environment

The `network_defense.py` file contains an implementation of a network defense environment based on the Cage Challenge 2.

### NetworkDefenseEnv

```python
class NetworkDefenseEnv(gym.Env)
```

In the network defense environment, the defender must choose actions to protect the network from attacks.

#### Key Parameters

- `num_nodes`: Number of nodes in the network
- `max_steps`: Maximum number of steps per episode

#### State Space

The state space includes:
- Node statuses (secure/compromised)
- Connection statuses between nodes
- Attack indicators for each node

#### Action Space

For each node, the agent can perform one of these actions:
- `0`: Do nothing
- `1`: Isolate node (disconnect from network)
- `2`: Patch node (remove compromise)
- `3`: Restore node connections

## Autonomous Driving Environment

The `auto_driving.py` file contains an implementation of an autonomous driving environment.

### AutoDrivingEnv

```python
class AutoDrivingEnv(gym.Env)
```

In the autonomous driving environment, the agent controls a vehicle that must navigate through traffic while obeying traffic rules, avoiding collisions, and reaching its destination.

#### Key Parameters

- `max_steps`: Maximum number of steps per episode

#### State Space

The state space includes:
- Ego vehicle state (position, speed, heading)
- Obstacle states (positions, speeds, headings)
- Goal position
- Time remaining

#### Action Space

The action space is continuous and includes:
- `steering`: -1 (full left) to 1 (full right)
- `acceleration`: -1 (full brake) to 1 (full gas)

#### Reward Function

The reward function includes:
- Progress reward: Reward for moving toward the goal
- Collision penalty: Penalty for colliding with obstacles
- Lane violation penalty: Penalty for crossing lane boundaries
- Speed violation penalty: Penalty for exceeding the speed limit
- Goal reward: Large reward for reaching the goal
