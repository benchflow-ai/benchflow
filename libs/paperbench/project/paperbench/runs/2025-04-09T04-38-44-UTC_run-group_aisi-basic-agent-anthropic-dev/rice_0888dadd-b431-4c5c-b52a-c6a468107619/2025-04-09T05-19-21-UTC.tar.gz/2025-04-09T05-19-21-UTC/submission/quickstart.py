#!/usr/bin/env python3

import os
import argparse
import subprocess
import sys

BANNER = '''
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                                                                              ┃
┃  ██████╗ ██╗ ██████╗███████╗                                                 ┃
┃  ██╔══██╗██║██╔════╝██╔════╝                                                 ┃
┃  ██████╔╝██║██║     █████╗                                                   ┃
┃  ██╔══██╗██║██║     ██╔══╝                                                   ┃
┃  ██║  ██║██║╚██████╗███████╗                                                 ┃
┃  ╚═╝  ╚═╝╚═╝ ╚═════╝╚══════╝                                                 ┃
┃                                                                              ┃
┃  Breaking Through the Training Bottlenecks of Reinforcement Learning         ┃
┃  with Explanation                                                            ┃
┃                                                                              ┃
┃  Quick Start Guide                                                           ┃
┃                                                                              ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
'''

def parse_args():
    parser = argparse.ArgumentParser(description='RICE Quick Start Guide')
    
    parser.add_argument('--install', action='store_true',
                        help='Install RICE and its dependencies')
    
    parser.add_argument('--setup-example', action='store_true',
                        help='Set up a minimal example')
    
    parser.add_argument('--run-tutorial', action='store_true',
                        help='Run the Jupyter notebook tutorial')
    
    parser.add_argument('--output-dir', type=str, default='./quickstart',
                        help='Directory to save example outputs')
    
    return parser.parse_args()

def print_step(step_num, title):
    print(f"\n{'=' * 80}")
    print(f"Step {step_num}: {title}")
    print(f"{'=' * 80}")

def run_command(cmd, check=True):
    print(f"Running: {cmd}")
    try:
        subprocess.run(cmd, shell=True, check=check)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Command failed: {e}")
        return False

def install_rice():
    print_step(1, "Installing RICE and its dependencies")
    
    if os.path.exists("./install.sh"):
        success = run_command("bash ./install.sh")
    else:
        success = run_command("pip install -e .")
    
    if success:
        print("✅ RICE installation successful!")
    else:
        print("❌ RICE installation failed. Please check the error messages above.")
        sys.exit(1)

def setup_example(output_dir):
    print_step(2, "Setting up a minimal example")
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Set up a minimal example
    print("\nTraining a simple PPO agent on CartPole-v1...")
    if not run_command(f"python -m rice.scripts.minimal_example"):
        print("❌ Minimal example failed. Please check the error messages above.")
        return False
    
    print("\n✅ Minimal example completed successfully!")
    print(f"Results saved to ./minimal_example_results/")
    
    return True

def show_tutorial():
    print_step(3, "Opening Jupyter notebook tutorial")
    
    if not os.path.exists("./examples/rice_tutorial.ipynb"):
        print("❌ Tutorial notebook not found. Please check that the repository is properly set up.")
        return False
    
    print("To run the tutorial:")
    print("1. Start Jupyter notebook:")
    print("   jupyter notebook ./examples/rice_tutorial.ipynb")
    print("2. Follow the instructions in the notebook")
    
    try:
        import jupyter
        print("\nJupyter is installed. You can also run the tutorial with:")
        print("jupyter notebook ./examples/rice_tutorial.ipynb")
    except ImportError:
        print("\nJupyter is not installed. To install it, run:")
        print("pip install jupyter")
    
    return True

def show_next_steps():
    print_step(4, "Next Steps")
    
    print("Now that you've set up RICE, here are some things you can do:")
    print("")
    print("1. Train a base agent on a specific environment:")
    print("   python -m rice.scripts.train_agent --env hopper --timesteps 1000000")
    print("")
    print("2. Train a mask network for a pre-trained agent:")
    print("   python -m rice.scripts.train_mask --env hopper --agent-path ./results/base_agents/hopper/hopper_agent.zip")
    print("")
    print("3. Refine an agent with RICE:")
    print("   python -m rice.scripts.train_rice --env hopper --agent-path ./path/to/agent.zip --mask-path ./path/to/mask.pt")
    print("")
    print("4. Compare different refining methods:")
    print("   python -m rice.scripts.compare_refining --env hopper --agent-path ./path/to/agent.zip --mask-path ./path/to/mask.pt")
    print("")
    print("5. Run all experiments for paper reproduction:")
    print("   python -m rice.scripts.run_all_experiments")
    print("")
    print("6. Use the Makefile for common operations:")
    print("   make test_all                # Run all tests")
    print("   make minimal                 # Run minimal example")
    print("   make hopper                  # Run experiments for Hopper")
    print("   make visualize_critical_states ENV=hopper AGENT_PATH=... MASK_PATH=...  # Visualize critical states")
    print("")
    print("For more information, see the README.md and documentation in the docs/ directory.")

def main():
    args = parse_args()
    
    print(BANNER)
    
    if not args.install and not args.setup_example and not args.run_tutorial:
        # If no options provided, show menu
        print("Please select an option:")
        print("1. Install RICE and its dependencies")
        print("2. Set up a minimal example")
        print("3. Run the Jupyter notebook tutorial")
        print("4. Show next steps")
        print("5. Exit")
        
        choice = input("Enter your choice (1-5): ")
        
        if choice == "1":
            install_rice()
            print("\nWould you like to set up a minimal example now? (y/n)")
            if input().lower() == 'y':
                setup_example(args.output_dir)
        elif choice == "2":
            setup_example(args.output_dir)
        elif choice == "3":
            show_tutorial()
        elif choice == "4":
            show_next_steps()
        else:
            print("Exiting...")
            return
    else:
        # Execute specified options
        if args.install:
            install_rice()
        
        if args.setup_example:
            setup_example(args.output_dir)
        
        if args.run_tutorial:
            show_tutorial()
    
    # Always show next steps
    show_next_steps()
    
    print("\nThank you for using RICE! Happy refining!")

if __name__ == "__main__":
    main()
