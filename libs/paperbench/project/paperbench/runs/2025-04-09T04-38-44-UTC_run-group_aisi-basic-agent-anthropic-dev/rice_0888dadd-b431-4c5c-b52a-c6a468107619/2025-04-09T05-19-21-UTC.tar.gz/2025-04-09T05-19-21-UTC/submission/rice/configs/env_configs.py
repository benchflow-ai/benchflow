# Configurations for MuJoCo environments
hopper_config = {
    'env_name': 'hopper',
    'timesteps': 100000,
    'mask_bonus': 0.01,
    'reset_prob': 0.5,
    'exploration_coef': 0.01,
}

walker2d_config = {
    'env_name': 'walker2d',
    'timesteps': 100000,
    'mask_bonus': 0.01,
    'reset_prob': 0.5,
    'exploration_coef': 0.01,
}

reacher_config = {
    'env_name': 'reacher',
    'timesteps': 100000,
    'mask_bonus': 0.01,
    'reset_prob': 0.5,
    'exploration_coef': 0.01,
}

halfcheetah_config = {
    'env_name': 'halfcheetah',
    'timesteps': 100000,
    'mask_bonus': 0.01,
    'reset_prob': 0.5,
    'exploration_coef': 0.01,
}

# Configurations for sparse reward MuJoCo environments
sparse_hopper_config = {
    'env_name': 'sparse_hopper',
    'timesteps': 150000,
    'mask_bonus': 0.01,
    'reset_prob': 0.5,
    'exploration_coef': 0.1,  # Higher exploration coefficient for sparse environments
}

sparse_walker2d_config = {
    'env_name': 'sparse_walker2d',
    'timesteps': 150000,
    'mask_bonus': 0.01,
    'reset_prob': 0.5,
    'exploration_coef': 0.1,
}

sparse_halfcheetah_config = {
    'env_name': 'sparse_halfcheetah',
    'timesteps': 150000,
    'mask_bonus': 0.01,
    'reset_prob': 0.5,
    'exploration_coef': 0.1,
}

# Configurations for real-world applications
selfish_mining_config = {
    'env_name': 'selfish_mining',
    'timesteps': 100000,
    'mask_bonus': 0.01,
    'reset_prob': 0.5,
    'exploration_coef': 0.01,
}

network_defense_config = {
    'env_name': 'network_defense',
    'timesteps': 100000,
    'mask_bonus': 0.01,
    'reset_prob': 0.5,
    'exploration_coef': 0.01,
}

auto_driving_config = {
    'env_name': 'auto_driving',
    'timesteps': 100000,
    'mask_bonus': 0.01,
    'reset_prob': 0.5,
    'exploration_coef': 0.01,
}

# Dictionary mapping environment names to their configs
ENV_CONFIGS = {
    'hopper': hopper_config,
    'walker2d': walker2d_config,
    'reacher': reacher_config,
    'halfcheetah': halfcheetah_config,
    'sparse_hopper': sparse_hopper_config,
    'sparse_walker2d': sparse_walker2d_config,
    'sparse_halfcheetah': sparse_halfcheetah_config,
    'selfish_mining': selfish_mining_config,
    'network_defense': network_defense_config,
    'auto_driving': auto_driving_config,
}

def get_config(env_name):
    """Get configuration for a specific environment"""
    if env_name in ENV_CONFIGS:
        return ENV_CONFIGS[env_name]
    else:
        raise ValueError(f"Unknown environment: {env_name}")
