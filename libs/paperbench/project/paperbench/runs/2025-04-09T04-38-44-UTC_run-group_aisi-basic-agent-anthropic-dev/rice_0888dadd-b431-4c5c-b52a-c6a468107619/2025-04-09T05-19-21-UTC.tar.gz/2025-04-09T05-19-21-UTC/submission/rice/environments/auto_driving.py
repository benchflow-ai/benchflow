import gymnasium as gym
from gymnasium import spaces
import numpy as np
import random
import math

class AutoDrivingEnv(gym.Env):
    """
    Simplified autonomous driving environment based on the paper.
    
    The agent controls a vehicle that must navigate through traffic while
    obeying traffic rules, avoiding collisions, and reaching its destination.
    """
    def __init__(self, max_steps=500):
        super(AutoDrivingEnv, self).__init__()
        
        self.max_steps = max_steps
        
        # State space: [
        #   ego_x, ego_y, ego_speed, ego_heading,
        #   [obstacle_1_x, obstacle_1_y, obstacle_1_speed, obstacle_1_heading],
        #   [obstacle_2_x, obstacle_2_y, obstacle_2_speed, obstacle_2_heading],
        #   ...
        #   goal_x, goal_y, time_remaining
        # ]
        self.num_obstacles = 5
        state_size = 4 + self.num_obstacles * 4 + 2 + 1  # 27-dimensional state
        
        self.observation_space = spaces.Box(
            low=-1, high=1,
            shape=(state_size,),
            dtype=np.float32
        )
        
        # Action space: [steering, acceleration]
        # steering: -1 (full left) to 1 (full right)
        # acceleration: -1 (full brake) to 1 (full gas)
        self.action_space = spaces.Box(
            low=np.array([-1.0, -1.0]),
            high=np.array([1.0, 1.0]),
            dtype=np.float32
        )
        
        # Environment parameters
        self.world_width = 20.0  # meters
        self.world_length = 100.0  # meters
        self.lane_width = 3.5  # meters
        self.num_lanes = 3
        self.max_speed = 30.0  # m/s (108 km/h)
        
        # Vehicle parameters
        self.ego_length = 4.5  # meters
        self.ego_width = 2.0  # meters
        
        # Initialize state
        self.steps = 0
        self.reset_environment()
        
    def reset_environment(self):
        """Initialize the environment state"""
        # Initialize ego vehicle
        self.ego_x = self.world_width / 2  # Middle of the road
        self.ego_y = 10.0  # Near the start
        self.ego_speed = 10.0  # m/s (36 km/h)
        self.ego_heading = 0.0  # radians (facing forward)
        
        # Initialize obstacles
        self.obstacles = []
        for _ in range(self.num_obstacles):
            # Random position ahead of the ego vehicle
            x = random.uniform(0, self.world_width)
            y = random.uniform(self.ego_y + 10, self.world_length - 10)
            speed = random.uniform(5, 25)  # m/s
            heading = 0.0  # radians (facing forward)
            
            self.obstacles.append([x, y, speed, heading])
        
        # Initialize goal
        self.goal_x = self.world_width / 2
        self.goal_y = self.world_length - 10
        
        # Initialize time
        self.time_remaining = 1.0  # normalized from 0 to 1
        
        # Initialize metrics
        self.distance_traveled = 0
        self.collisions = 0
        self.lane_violations = 0
        self.speed_violations = 0
        
    def _get_state(self):
        """Convert internal state to observation array"""
        # Normalize state values to [-1, 1]
        norm_ego_x = (self.ego_x / self.world_width) * 2 - 1
        norm_ego_y = (self.ego_y / self.world_length) * 2 - 1
        norm_ego_speed = (self.ego_speed / self.max_speed) * 2 - 1
        norm_ego_heading = self.ego_heading / math.pi
        
        state = [norm_ego_x, norm_ego_y, norm_ego_speed, norm_ego_heading]
        
        for obstacle in self.obstacles:
            x, y, speed, heading = obstacle
            norm_x = (x / self.world_width) * 2 - 1
            norm_y = (y / self.world_length) * 2 - 1
            norm_speed = (speed / self.max_speed) * 2 - 1
            norm_heading = heading / math.pi
            
            state.extend([norm_x, norm_y, norm_speed, norm_heading])
        
        # Pad if there are fewer than expected obstacles
        missing_obstacles = self.num_obstacles - len(self.obstacles)
        if missing_obstacles > 0:
            state.extend([-1, -1, 0, 0] * missing_obstacles)
        
        # Add goal position
        norm_goal_x = (self.goal_x / self.world_width) * 2 - 1
        norm_goal_y = (self.goal_y / self.world_length) * 2 - 1
        state.extend([norm_goal_x, norm_goal_y])
        
        # Add time remaining
        state.append(self.time_remaining)
        
        return np.array(state, dtype=np.float32)
        
    def reset(self, seed=None):
        """Reset the environment to initial state"""
        super().reset(seed=seed)
        
        self.steps = 0
        self.reset_environment()
        
        return self._get_state(), {}
    
    def _check_collision(self):
        """Check if the ego vehicle collides with any obstacle"""
        ego_left = self.ego_x - self.ego_width / 2
        ego_right = self.ego_x + self.ego_width / 2
        ego_front = self.ego_y + self.ego_length / 2
        ego_back = self.ego_y - self.ego_length / 2
        
        for obstacle in self.obstacles:
            obs_x, obs_y, _, _ = obstacle
            obs_left = obs_x - self.ego_width / 2
            obs_right = obs_x + self.ego_width / 2
            obs_front = obs_y + self.ego_length / 2
            obs_back = obs_y - self.ego_length / 2
            
            # Check overlap
            if (ego_left < obs_right and ego_right > obs_left and
                ego_back < obs_front and ego_front > obs_back):
                return True
                
        return False
    
    def _check_lane_violation(self):
        """Check if the ego vehicle crosses lane boundaries"""
        # Simple check for now: just make sure it's on the road
        return self.ego_x < 0 or self.ego_x > self.world_width
    
    def _check_speed_violation(self):
        """Check if the ego vehicle exceeds speed limit"""
        return self.ego_speed > self.max_speed
    
    def _check_goal_reached(self):
        """Check if the ego vehicle reached the goal"""
        distance_to_goal = math.sqrt((self.ego_x - self.goal_x)**2 + (self.ego_y - self.goal_y)**2)
        return distance_to_goal < 3.0  # Reached if within 3 meters
    
    def step(self, action):
        """
        Take a step in the environment with the given action.
        
        Actions:
        - steering: -1 (full left) to 1 (full right)
        - acceleration: -1 (full brake) to 1 (full gas)
        
        Returns:
            obs: New state
            reward: Reward for this step
            terminated: Whether the episode is over
            truncated: Whether the episode is truncated
            info: Additional information
        """
        self.steps += 1
        
        # Extract actions
        steering = action[0]  # -1 to 1
        acceleration = action[1]  # -1 to 1
        
        # Update ego vehicle position and state
        # Heading update based on steering
        self.ego_heading += steering * 0.1  # Max 0.1 rad per step
        
        # Speed update based on acceleration
        self.ego_speed += acceleration * 2.0  # Max 2 m/s^2
        self.ego_speed = max(0, min(self.ego_speed, self.max_speed * 1.2))  # Allow some speeding
        
        # Position update based on heading and speed
        prev_y = self.ego_y
        self.ego_x += math.sin(self.ego_heading) * self.ego_speed * 0.1  # 0.1 is time step
        self.ego_y += math.cos(self.ego_heading) * self.ego_speed * 0.1
        
        # Constrain to road
        self.ego_x = max(0, min(self.ego_x, self.world_width))
        self.ego_y = max(0, min(self.ego_y, self.world_length))
        
        # Calculate distance traveled
        self.distance_traveled += self.ego_y - prev_y
        
        # Update obstacles
        for i, obstacle in enumerate(self.obstacles):
            x, y, speed, heading = obstacle
            x += math.sin(heading) * speed * 0.1
            y += math.cos(heading) * speed * 0.1
            
            # Remove obstacles that are too far or behind
            if y < self.ego_y - 20 or y > self.ego_y + 150 or x < -10 or x > self.world_width + 10:
                # Create a new obstacle
                new_x = random.uniform(0, self.world_width)
                new_y = self.ego_y + random.uniform(50, 100)
                new_speed = random.uniform(5, 25)
                new_heading = 0.0
                
                self.obstacles[i] = [new_x, new_y, new_speed, new_heading]
            else:
                self.obstacles[i] = [x, y, speed, heading]
        
        # Update time remaining
        self.time_remaining = max(0, 1 - self.steps / self.max_steps)
        
        # Check for violations
        collision = self._check_collision()
        lane_violation = self._check_lane_violation()
        speed_violation = self._check_speed_violation()
        goal_reached = self._check_goal_reached()
        
        if collision:
            self.collisions += 1
        if lane_violation:
            self.lane_violations += 1
        if speed_violation:
            self.speed_violations += 1
        
        # Calculate reward
        reward = 0
        
        # Progress reward
        reward += (self.ego_y - prev_y) * 0.1
        
        # Penalty for collisions (severe)
        if collision:
            reward -= 10.0
        
        # Penalty for lane violations
        if lane_violation:
            reward -= 1.0
        
        # Penalty for speed violations
        if speed_violation:
            reward -= (self.ego_speed - self.max_speed) * 0.1
        
        # Reward for reaching goal
        if goal_reached:
            reward += 20.0
        
        # Check if episode is over
        terminated = collision or goal_reached or self.steps >= self.max_steps
        truncated = False
        
        # Create new observation
        obs = self._get_state()
        
        # Additional info
        info = {
            'distance_traveled': self.distance_traveled,
            'collisions': self.collisions,
            'lane_violations': self.lane_violations,
            'speed_violations': self.speed_violations,
            'goal_reached': goal_reached,
        }
        
        return obs, reward, terminated, truncated, info
    
    def render(self):
        """Render the environment (simple text-based output)"""
        print(f"Step: {self.steps}/{self.max_steps}")
        print(f"Ego vehicle: pos=({self.ego_x:.1f}, {self.ego_y:.1f}), speed={self.ego_speed:.1f}, heading={self.ego_heading:.2f}")
        print(f"Goal: ({self.goal_x:.1f}, {self.goal_y:.1f})")
        print(f"Distance traveled: {self.distance_traveled:.1f}")
        print(f"Violations: collisions={self.collisions}, lane={self.lane_violations}, speed={self.speed_violations}")
        
    def close(self):
        """Close the environment"""
        pass
