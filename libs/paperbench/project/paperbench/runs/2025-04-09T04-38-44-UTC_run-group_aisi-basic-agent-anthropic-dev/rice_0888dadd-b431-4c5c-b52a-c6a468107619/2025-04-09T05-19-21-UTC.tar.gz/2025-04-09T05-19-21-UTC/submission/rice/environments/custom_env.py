
# Example configuration for a custom environment
from gymnasium.spaces import Box, Discrete
import numpy as np
import gymnasium as gym

from rice.utils.state_reset import StateResetWrapper

# Define a simple custom environment
class CustomEnvironment(gym.Env):
    """
    Example custom environment that can be used with RICE.
    
    This is a simple 2D grid world where the agent needs to reach a goal.
    The agent can move in four directions: up, down, left, right.
    The agent receives a reward of -0.1 for each step, and +1 for reaching the goal.
    """
    metadata = {'render_modes': ['human', 'rgb_array'], 'render_fps': 4}
    
    def __init__(self, grid_size=10, max_steps=100):
        super(CustomEnvironment, self).__init__()
        
        self.grid_size = grid_size
        self.max_steps = max_steps
        
        # Define action and observation space
        self.action_space = Discrete(4)  # 0: up, 1: right, 2: down, 3: left
        self.observation_space = Box(low=0, high=1, shape=(2,), dtype=np.float32)
        
        # Initialize state
        self.agent_position = None
        self.goal_position = None
        self.steps = 0
        
        # Reset environment
        self.reset()
    
    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed)
        
        # Reset agent position to bottom-left corner
        self.agent_position = np.array([0, 0])
        
        # Reset goal position to top-right corner
        self.goal_position = np.array([self.grid_size - 1, self.grid_size - 1])
        
        # Reset step counter
        self.steps = 0
        
        # Return normalized observation
        return self._get_observation(), {}
    
    def step(self, action):
        # Increment step counter
        self.steps += 1
        
        # Move agent based on action
        if action == 0:  # up
            self.agent_position[1] = min(self.agent_position[1] + 1, self.grid_size - 1)
        elif action == 1:  # right
            self.agent_position[0] = min(self.agent_position[0] + 1, self.grid_size - 1)
        elif action == 2:  # down
            self.agent_position[1] = max(self.agent_position[1] - 1, 0)
        elif action == 3:  # left
            self.agent_position[0] = max(self.agent_position[0] - 1, 0)
        
        # Check if agent reached goal
        done = np.array_equal(self.agent_position, self.goal_position)
        
        # Calculate reward
        reward = 1.0 if done else -0.1
        
        # Check if maximum steps reached
        truncated = self.steps >= self.max_steps
        
        # Return observation, reward, done, info
        return self._get_observation(), reward, done, truncated, {}
    
    def _get_observation(self):
        # Normalize agent position to [0, 1]
        return self.agent_position / (self.grid_size - 1)
    
    def render(self, mode='human'):
        # Simple text-based rendering
        grid = [['.' for _ in range(self.grid_size)] for _ in range(self.grid_size)]
        grid[self.grid_size - 1 - self.agent_position[1]][self.agent_position[0]] = 'A'
        grid[self.grid_size - 1 - self.goal_position[1]][self.goal_position[0]] = 'G'
        
        for row in grid:
            print(' '.join(row))
        print()
    
    def close(self):
        pass
    
    # Custom methods to support RICE's state resetting
    def get_state(self):
        """Get the current environment state"""
        return {
            'agent_position': self.agent_position.copy(),
            'goal_position': self.goal_position.copy(),
            'steps': self.steps,
            'observation': self._get_observation()
        }
    
    def reset_to_state(self, state):
        """Reset the environment to the given state"""
        self.agent_position = state['agent_position'].copy()
        self.goal_position = state['goal_position'].copy()
        self.steps = state['steps']
        
        return self._get_observation(), {}

# Function to create the environment with appropriate wrappers
def create_custom_environment():
    """Create the custom environment with appropriate wrappers"""
    env = CustomEnvironment(grid_size=10, max_steps=100)
    
    # Wrap with StateResetWrapper to enable RICE's state resetting
    env = StateResetWrapper(env)
    
    return env

# Register the environment with Gymnasium (optional)
try:
    gym.register(
        id='CustomEnv-v0',
        entry_point='rice.environments.custom_env:create_custom_environment'
    )
except:
    pass  # Environment might already be registered

# Configuration for the custom environment
custom_env_config = {
    'timesteps': 100000,  # Number of timesteps for training
    'mask_bonus': 0.01,   # Bonus for masking
    'reset_prob': 0.5,    # Probability of resetting to critical states
    'exploration_coef': 0.01,  # Coefficient for RND exploration bonus
    'policy_kwargs': {
        'net_arch': [64, 64]  # Network architecture
    }
}

# Add the custom environment to the environment registry
if __name__ == "__main__":
    # Example usage
    env = create_custom_environment()
    print("Observation space:", env.observation_space)
    print("Action space:", env.action_space)
    
    # Test environment
    obs, _ = env.reset()
    done = False
    total_reward = 0
    
    while not done:
        action = env.action_space.sample()
        obs, reward, terminated, truncated, _ = env.step(action)
        total_reward += reward
        done = terminated or truncated
        
        env.render()
    
    print(f"Episode completed with total reward: {total_reward}")
