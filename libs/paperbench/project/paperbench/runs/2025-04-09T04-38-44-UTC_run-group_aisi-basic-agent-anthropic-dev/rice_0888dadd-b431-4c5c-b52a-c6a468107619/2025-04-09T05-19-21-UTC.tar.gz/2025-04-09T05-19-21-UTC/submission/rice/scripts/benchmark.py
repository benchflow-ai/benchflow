#!/usr/bin/env python3

import os
import argparse
import json
import numpy as np
import torch
import matplotlib.pyplot as plt
import pandas as pd
import time
from datetime import datetime
import subprocess

def parse_args():
    parser = argparse.ArgumentParser(description='Benchmark RICE against baselines')
    
    parser.add_argument('--environments', type=str, default='all',
                        help='Comma-separated list of environments to test, or "all"')
    
    parser.add_argument('--methods', type=str, default='all',
                        help='Comma-separated list of methods to test, or "all"')
    
    parser.add_argument('--timesteps', type=int, default=50000,
                        help='Number of timesteps per method')
    
    parser.add_argument('--n-seeds', type=int, default=3,
                        help='Number of random seeds to test')
    
    parser.add_argument('--base-dir', type=str, default='./results/benchmark',
                        help='Base directory for benchmark results')
    
    parser.add_argument('--skip-existing', action='store_true',
                        help='Skip benchmarks that already have results')
    
    parser.add_argument('--parallel', action='store_true',
                        help='Run benchmarks in parallel (requires GNU parallel)')
    
    return parser.parse_args()

def get_environments():
    """Get the list of all available environments"""
    return [
        'hopper',
        'walker2d',
        'reacher',
        'halfcheetah',
        'sparse_hopper',
        'sparse_walker2d',
        'sparse_halfcheetah',
        'selfish_mining',
        'network_defense',
        'auto_driving'
    ]

def get_methods():
    """Get the list of all available methods"""
    return [
        'no_refine',
        'ppo_finetuning',
        'jsrl',
        'statemask_reset',
        'rice'
    ]

def generate_benchmark_commands(environments, methods, timesteps, n_seeds, base_dir):
    """Generate commands for each benchmark configuration"""
    commands = []
    
    for env in environments:
        for method in methods:
            for seed in range(n_seeds):
                # Skip 'no_refine' as it doesn't involve training
                if method == 'no_refine':
                    continue
                
                # Define output directory
                output_dir = os.path.join(base_dir, env, method, f"seed_{seed}")
                
                # Create command
                if method == 'rice':
                    # For RICE, we need to train the mask network first
                    mask_dir = os.path.join(base_dir, env, 'mask', f"seed_{seed}")
                    os.makedirs(mask_dir, exist_ok=True)
                    
                    # First train a mask network
                    mask_cmd = (
                        f"python -m rice.scripts.train_mask "
                        f"--env {env} "
                        f"--agent-path {os.path.join(base_dir, env, 'agent', f'seed_{seed}', f'{env}_agent.zip')} "
                        f"--mask-save-path {mask_dir} "
                        f"--timesteps {timesteps // 2} "
                        f"--seed {seed}"
                    )
                    
                    # Then train with RICE
                    rice_cmd = (
                        f"python -m rice.scripts.train_rice "
                        f"--env {env} "
                        f"--agent-path {os.path.join(base_dir, env, 'agent', f'seed_{seed}', f'{env}_agent.zip')} "
                        f"--mask-path {os.path.join(mask_dir, f'{env}_mask.pt')} "
                        f"--save-path {output_dir} "
                        f"--timesteps {timesteps} "
                        f"--seed {seed}"
                    )
                    
                    commands.append((f"{env}_{method}_seed{seed}_mask", mask_cmd, mask_dir))
                    commands.append((f"{env}_{method}_seed{seed}", rice_cmd, output_dir))
                
                elif method == 'statemask_reset':
                    # For StateMask-R, we also need to train the mask network first
                    mask_dir = os.path.join(base_dir, env, 'mask', f"seed_{seed}")
                    os.makedirs(mask_dir, exist_ok=True)
                    
                    # First train a mask network (if not already done for RICE)
                    if not os.path.exists(os.path.join(mask_dir, f'{env}_mask.pt')):
                        mask_cmd = (
                            f"python -m rice.scripts.train_mask "
                            f"--env {env} "
                            f"--agent-path {os.path.join(base_dir, env, 'agent', f'seed_{seed}', f'{env}_agent.zip')} "
                            f"--mask-save-path {mask_dir} "
                            f"--timesteps {timesteps // 2} "
                            f"--seed {seed}"
                        )
                        commands.append((f"{env}_{method}_seed{seed}_mask", mask_cmd, mask_dir))
                    
                    # Then refine with StateMask-R
                    statemask_cmd = (
                        f"python -m rice.scripts.compare_refining "
                        f"--env {env} "
                        f"--agent-path {os.path.join(base_dir, env, 'agent', f'seed_{seed}', f'{env}_agent.zip')} "
                        f"--mask-path {os.path.join(mask_dir, f'{env}_mask.pt')} "
                        f"--output-dir {output_dir} "
                        f"--timesteps {timesteps} "
                        f"--method statemask_reset "
                        f"--seed {seed}"
                    )
                    
                    commands.append((f"{env}_{method}_seed{seed}", statemask_cmd, output_dir))
                
                elif method == 'ppo_finetuning':
                    # Simple PPO fine-tuning
                    ppo_cmd = (
                        f"python -m rice.scripts.compare_refining "
                        f"--env {env} "
                        f"--agent-path {os.path.join(base_dir, env, 'agent', f'seed_{seed}', f'{env}_agent.zip')} "
                        f"--output-dir {output_dir} "
                        f"--timesteps {timesteps} "
                        f"--method ppo_finetuning "
                        f"--seed {seed}"
                    )
                    
                    commands.append((f"{env}_{method}_seed{seed}", ppo_cmd, output_dir))
                
                elif method == 'jsrl':
                    # JSRL method
                    jsrl_cmd = (
                        f"python -m rice.scripts.compare_refining "
                        f"--env {env} "
                        f"--agent-path {os.path.join(base_dir, env, 'agent', f'seed_{seed}', f'{env}_agent.zip')} "
                        f"--output-dir {output_dir} "
                        f"--timesteps {timesteps} "
                        f"--method jsrl "
                        f"--seed {seed}"
                    )
                    
                    commands.append((f"{env}_{method}_seed{seed}", jsrl_cmd, output_dir))
    
    return commands

def run_benchmark_sequential(commands, skip_existing=False):
    """Run all benchmark commands sequentially"""
    for name, cmd, output_dir in commands:
        # Check if we should skip this benchmark
        if skip_existing and os.path.exists(os.path.join(output_dir, "complete.txt")):
            print(f"Skipping {name} (already completed)")
            continue
        
        print(f"Running {name}...")
        print(f"Command: {cmd}")
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        # Run the command
        try:
            start_time = time.time()
            process = subprocess.run(cmd, shell=True, check=True, capture_output=True, text=True)
            elapsed_time = time.time() - start_time
            
            # Save output
            with open(os.path.join(output_dir, "output.log"), "w") as f:
                f.write(process.stdout)
            
            # Save error output if any
            if process.stderr:
                with open(os.path.join(output_dir, "error.log"), "w") as f:
                    f.write(process.stderr)
            
            # Mark as complete
            with open(os.path.join(output_dir, "complete.txt"), "w") as f:
                f.write(f"Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Elapsed time: {elapsed_time:.2f} seconds\n")
            
            print(f"Successfully completed {name} in {elapsed_time:.2f} seconds")
            
        except subprocess.CalledProcessError as e:
            print(f"Error running {name}: {e}")
            
            # Save error output
            with open(os.path.join(output_dir, "error.log"), "w") as f:
                f.write(f"Error: {str(e)}\n\n")
                f.write(e.stdout + "\n")
                f.write(e.stderr)
                
            # Mark as failed
            with open(os.path.join(output_dir, "failed.txt"), "w") as f:
                f.write(f"Failed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Error: {str(e)}\n")

def run_benchmark_parallel(commands, skip_existing=False):
    """Run all benchmark commands in parallel using GNU parallel"""
    # First, create all output directories
    for _, _, output_dir in commands:
        os.makedirs(output_dir, exist_ok=True)
    
    # Create a commands file
    commands_file = "benchmark_commands.txt"
    with open(commands_file, "w") as f:
        for name, cmd, output_dir in commands:
            # Check if we should skip this benchmark
            if skip_existing and os.path.exists(os.path.join(output_dir, "complete.txt")):
                continue
                
            f.write(f"{cmd} && echo 'Completed at: $(date)' > {output_dir}/complete.txt || echo 'Failed at: $(date)' > {output_dir}/failed.txt\n")
    
    # Run with GNU parallel
    parallel_cmd = f"parallel --bar < {commands_file}"
    subprocess.run(parallel_cmd, shell=True, check=True)
    
    # Remove the commands file
    os.remove(commands_file)

def analyze_results(environments, methods, n_seeds, base_dir):
    """Analyze benchmark results and generate tables/figures"""
    # Create a results DataFrame
    results = pd.DataFrame(columns=['Environment', 'Method', 'Seed', 'Reward', 'Std'])
    
    # Collect results
    for env in environments:
        for method in methods:
            for seed in range(n_seeds):
                if method == 'no_refine':
                    # For no_refine, get the results from the agent evaluation
                    eval_file = os.path.join(base_dir, env, 'agent', f"seed_{seed}", "final_evaluation.txt")
                    if os.path.exists(eval_file):
                        with open(eval_file, "r") as f:
                            lines = f.readlines()
                            
                            # Extract reward from the file
                            for line in lines:
                                if line.startswith("Mean reward:"):
                                    reward = float(line.split(":")[1].strip())
                                elif line.startswith("Std dev:"):
                                    std = float(line.split(":")[1].strip())
                            
                            # Add to results
                            results = results.append({
                                'Environment': env,
                                'Method': method,
                                'Seed': seed,
                                'Reward': reward,
                                'Std': std
                            }, ignore_index=True)
                else:
                    # For other methods, look in their respective directories
                    result_file = os.path.join(base_dir, env, method, f"seed_{seed}", "results.json")
                    if os.path.exists(result_file):
                        with open(result_file, "r") as f:
                            method_results = json.load(f)
                            
                            # Add to results
                            results = results.append({
                                'Environment': env,
                                'Method': method,
                                'Seed': seed,
                                'Reward': method_results['mean_reward'],
                                'Std': method_results['std_reward']
                            }, ignore_index=True)
    
    # Calculate aggregated statistics
    aggregated = results.groupby(['Environment', 'Method'])[['Reward', 'Std']].agg({
        'Reward': ['mean', 'std'],
        'Std': 'mean'
    }).reset_index()
    
    aggregated.columns = ['Environment', 'Method', 'Mean Reward', 'Reward Std', 'Mean Std']
    
    # Save results
    results.to_csv(os.path.join(base_dir, "benchmark_results.csv"), index=False)
    aggregated.to_csv(os.path.join(base_dir, "benchmark_aggregated.csv"), index=False)
    
    # Create plots
    create_benchmark_plots(aggregated, base_dir)
    
    return results, aggregated

def create_benchmark_plots(aggregated, base_dir):
    """Create various plots from the benchmark results"""
    try:
        import seaborn as sns
    except ImportError:
        print("Seaborn not installed. Some plots may not be created.")
        sns = None
    
    # Create a directory for plots
    plots_dir = os.path.join(base_dir, "plots")
    os.makedirs(plots_dir, exist_ok=True)
    
    # Plot 1: Bar chart comparing methods across environments
    environments = aggregated['Environment'].unique()
    methods = aggregated['Method'].unique()
    
    plt.figure(figsize=(15, 10))
    
    x = np.arange(len(environments))
    width = 0.15
    
    for i, method in enumerate(methods):
        method_data = aggregated[aggregated['Method'] == method]
        rewards = []
        errors = []
        
        for env in environments:
            env_data = method_data[method_data['Environment'] == env]
            if not env_data.empty:
                rewards.append(env_data['Mean Reward'].values[0])
                errors.append(env_data['Reward Std'].values[0])
            else:
                rewards.append(0)
                errors.append(0)
        
        plt.bar(x + i*width - width*2, rewards, width, label=method, yerr=errors, capsize=5)
    
    plt.xlabel('Environment')
    plt.ylabel('Mean Reward')
    plt.title('Method Performance Comparison Across Environments')
    plt.xticks(x, environments, rotation=45, ha='right')
    plt.legend()
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    
    plt.savefig(os.path.join(plots_dir, "method_comparison.png"), dpi=300)
    plt.close()
    
    # Plot 2: Improvement over 'no_refine' baseline
    for env in environments:
        env_data = aggregated[aggregated['Environment'] == env]
        
        if env_data.empty:
            continue
            
        baseline = env_data[env_data['Method'] == 'no_refine']
        
        if baseline.empty:
            continue
            
        baseline_reward = baseline['Mean Reward'].values[0]
        
        improvements = []
        method_names = []
        
        for method in methods:
            if method == 'no_refine':
                continue
                
            method_data = env_data[env_data['Method'] == method]
            
            if method_data.empty:
                continue
                
            method_reward = method_data['Mean Reward'].values[0]
            improvement = (method_reward - baseline_reward) / abs(baseline_reward) * 100
            
            improvements.append(improvement)
            method_names.append(method)
        
        plt.figure(figsize=(10, 6))
        plt.bar(method_names, improvements)
        plt.axhline(y=0, color='r', linestyle='-')
        plt.xlabel('Method')
        plt.ylabel('Improvement (%)')
        plt.title(f'Improvement over Baseline - {env}')
        plt.grid(axis='y', linestyle='--', alpha=0.7)
        plt.tight_layout()
        
        plt.savefig(os.path.join(plots_dir, f"{env}_improvement.png"), dpi=300)
        plt.close()
    
    # Plot 3: Heatmap of method performance
    if sns is not None:
        plt.figure(figsize=(12, 8))
        
        # Create a pivot table
        heatmap_data = aggregated.pivot(index='Environment', columns='Method', values='Mean Reward')
        
        # Create heatmap
        sns.heatmap(heatmap_data, annot=True, cmap='viridis', fmt='.1f', linewidths=.5)
        
        plt.title('Method Performance Heatmap')
        plt.tight_layout()
        plt.savefig(os.path.join(plots_dir, "performance_heatmap.png"), dpi=300)
        plt.close()

def main():
    args = parse_args()
    
    # Set random seed
    np.random.seed(0)
    torch.manual_seed(0)
    
    # Determine environments to test
    if args.environments == 'all':
        environments = get_environments()
    else:
        environments = args.environments.split(',')
        
    # Determine methods to test
    if args.methods == 'all':
        methods = get_methods()
    else:
        methods = args.methods.split(',')
    
    print(f"Running benchmark on environments: {', '.join(environments)}")
    print(f"Testing methods: {', '.join(methods)}")
    
    # Create base directory
    os.makedirs(args.base_dir, exist_ok=True)
    
    # Save benchmark configuration
    config = {
        'environments': environments,
        'methods': methods,
        'timesteps': args.timesteps,
        'n_seeds': args.n_seeds,
        'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    with open(os.path.join(args.base_dir, "benchmark_config.json"), "w") as f:
        json.dump(config, f, indent=2)
    
    # Generate commands
    commands = generate_benchmark_commands(environments, methods, args.timesteps, args.n_seeds, args.base_dir)
    
    # Train base agents first
    for env in environments:
        for seed in range(args.n_seeds):
            agent_dir = os.path.join(args.base_dir, env, 'agent', f"seed_{seed}")
            
            # Check if agent exists
            if not args.skip_existing or not os.path.exists(os.path.join(agent_dir, f"{env}_agent.zip")):
                # Create directory
                os.makedirs(agent_dir, exist_ok=True)
                
                # Train agent
                train_cmd = (
                    f"python -m rice.scripts.train_agent "
                    f"--env {env} "
                    f"--algorithm PPO "
                    f"--timesteps {args.timesteps * 10} "  # Train base agents for longer
                    f"--output-dir {agent_dir} "
                    f"--seed {seed}"
                )
                
                print(f"Training base agent for {env} (seed {seed})...")
                print(f"Command: {train_cmd}")
                
                try:
                    subprocess.run(train_cmd, shell=True, check=True)
                except subprocess.CalledProcessError as e:
                    print(f"Error training base agent for {env} (seed {seed}): {e}")
    
    # Run all benchmarks
    print(f"\nRunning {len(commands)} benchmark configurations...")
    
    if args.parallel:
        # Check if GNU parallel is installed
        try:
            subprocess.run(["parallel", "--version"], check=True, capture_output=True)
            run_benchmark_parallel(commands, args.skip_existing)
        except (subprocess.CalledProcessError, FileNotFoundError):
            print("GNU parallel not found. Falling back to sequential execution.")
            run_benchmark_sequential(commands, args.skip_existing)
    else:
        run_benchmark_sequential(commands, args.skip_existing)
    
    # Analyze results
    print("\nAnalyzing results...")
    results, aggregated = analyze_results(environments, methods, args.n_seeds, args.base_dir)
    
    # Print summary
    print("\nBenchmark completed!")
    print(f"Results saved to {args.base_dir}")
    print("\nSummary:")
    
    # Print a simple table of mean rewards
    summary = aggregated.pivot(index='Environment', columns='Method', values='Mean Reward')
    print(summary)
    
    print("\nCheck the plots directory for visualizations of the results.")

if __name__ == "__main__":
    main()
