#!/usr/bin/env python3

import os
import argparse
import numpy as np
import torch
import matplotlib.pyplot as plt
from stable_baselines3 import PPO, SAC
import gymnasium as gym

from rice.environments.mujoco_envs import create_env
from rice.environments.selfish_mining import SelfishMiningEnv
from rice.environments.network_defense import NetworkDefenseEnv
from rice.environments.auto_driving import AutoDrivingEnv

def parse_args():
    parser = argparse.ArgumentParser(description='Compare original and refined agents')
    
    parser.add_argument('--env', type=str, required=True,
                        help='Environment name')
    
    parser.add_argument('--original-agent', type=str, required=True,
                        help='Path to original agent')
    
    parser.add_argument('--refined-agent', type=str, required=True,
                        help='Path to refined agent')
    
    parser.add_argument('--method', type=str, default='RICE',
                        help='Name of the refining method (for plotting)')
    
    parser.add_argument('--n-episodes', type=int, default=10,
                        help='Number of episodes to evaluate')
    
    parser.add_argument('--record-video', action='store_true',
                        help='Record video of agent performance (if environment supports it)')
    
    parser.add_argument('--output-dir', type=str, default='./agent_comparison',
                        help='Directory to save results')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    return parser.parse_args()

def create_environment(env_name):
    """Create the specified environment"""
    if env_name in ['hopper', 'walker2d', 'reacher', 'halfcheetah', 
                   'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah']:
        return create_env(env_name)
    elif env_name == 'selfish_mining':
        return SelfishMiningEnv()
    elif env_name == 'network_defense':
        return NetworkDefenseEnv()
    elif env_name == 'auto_driving':
        return AutoDrivingEnv()
    else:
        # Try to load as a standard Gym environment
        try:
            return gym.make(env_name)
        except:
            raise ValueError(f"Unknown environment: {env_name}")

def load_agent(agent_path, env):
    """Load a trained agent"""
    try:
        # Try loading as PPO first
        return PPO.load(agent_path, env=env)
    except:
        try:
            # Try loading as SAC if PPO fails
            return SAC.load(agent_path, env=env)
        except Exception as e:
            raise ValueError(f"Failed to load agent from {agent_path}: {e}")

def evaluate_agent(agent, env, n_episodes=10, render=False):
    """Evaluate an agent's performance"""
    episode_rewards = []
    episode_lengths = []
    episode_trajectories = []
    
    for i in range(n_episodes):
        obs, _ = env.reset()
        states = [obs]
        actions = []
        rewards = []
        dones = []
        total_reward = 0
        steps = 0
        
        done = False
        while not done:
            action, _ = agent.predict(obs, deterministic=True)
            next_obs, reward, terminated, truncated, _ = env.step(action)
            
            if render:
                env.render()
                
            states.append(next_obs)
            actions.append(action)
            rewards.append(reward)
            
            total_reward += reward
            steps += 1
            
            obs = next_obs
            done = terminated or truncated
            dones.append(done)
            
        episode_rewards.append(total_reward)
        episode_lengths.append(steps)
        
        # Store trajectory data
        episode_trajectories.append({
            'states': np.array(states),
            'actions': np.array(actions),
            'rewards': np.array(rewards),
            'dones': np.array(dones),
            'total_reward': total_reward,
            'length': steps
        })
        
        print(f"Episode {i+1}/{n_episodes}: reward = {total_reward:.2f}, length = {steps}")
    
    return episode_rewards, episode_lengths, episode_trajectories

def plot_rewards_comparison(original_rewards, refined_rewards, method, output_dir):
    """Plot reward comparison between original and refined agents"""
    plt.figure(figsize=(12, 6))
    
    # Box plot
    plt.subplot(1, 2, 1)
    plt.boxplot([original_rewards, refined_rewards], labels=['Original', method])
    plt.ylabel('Episode Reward')
    plt.title('Reward Distribution')
    plt.grid(True, linestyle='--', alpha=0.7)
    
    # Bar plot with means
    plt.subplot(1, 2, 2)
    means = [np.mean(original_rewards), np.mean(refined_rewards)]
    stds = [np.std(original_rewards), np.std(refined_rewards)]
    
    plt.bar(['Original', method], means, yerr=stds, capsize=10)
    plt.ylabel('Mean Reward')
    plt.title('Average Performance')
    
    # Add improvement percentage
    improvement = (means[1] - means[0]) / abs(means[0]) * 100
    plt.text(1, means[1] + stds[1] + 0.1 * max(means), 
             f"+{improvement:.1f}%", 
             ha='center', va='center')
    
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "reward_comparison.png"), dpi=300)
    plt.close()

def plot_reward_curves(original_trajectories, refined_trajectories, method, output_dir):
    """Plot cumulative reward curves for original and refined agents"""
    plt.figure(figsize=(10, 6))
    
    # Plot original agent curves
    for i, traj in enumerate(original_trajectories):
        cumulative_rewards = np.cumsum(traj['rewards'])
        if i == 0:
            plt.plot(cumulative_rewards, color='blue', alpha=0.3, label='Original')
        else:
            plt.plot(cumulative_rewards, color='blue', alpha=0.3)
    
    # Plot refined agent curves
    for i, traj in enumerate(refined_trajectories):
        cumulative_rewards = np.cumsum(traj['rewards'])
        if i == 0:
            plt.plot(cumulative_rewards, color='green', alpha=0.3, label=method)
        else:
            plt.plot(cumulative_rewards, color='green', alpha=0.3)
    
    # Plot means
    original_mean = np.mean([np.cumsum(t['rewards']) for t in original_trajectories], axis=0)
    refined_mean = np.mean([np.cumsum(t['rewards']) for t in refined_trajectories], axis=0)
    
    # Truncate to minimum length
    min_len = min(len(original_mean), len(refined_mean))
    plt.plot(original_mean[:min_len], color='blue', linewidth=2, label='Original (Mean)')
    plt.plot(refined_mean[:min_len], color='green', linewidth=2, label=f'{method} (Mean)')
    
    plt.xlabel('Steps')
    plt.ylabel('Cumulative Reward')
    plt.title('Reward Accumulation')
    plt.legend()
    plt.grid(True, linestyle='--', alpha=0.7)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "reward_curves.png"), dpi=300)
    plt.close()

def analyze_episode_statistics(original_trajectories, refined_trajectories, method, output_dir):
    """Analyze and plot episode statistics"""
    # Extract episode lengths
    orig_lengths = [t['length'] for t in original_trajectories]
    refined_lengths = [t['length'] for t in refined_trajectories]
    
    # Plot episode lengths
    plt.figure(figsize=(10, 6))
    plt.boxplot([orig_lengths, refined_lengths], labels=['Original', method])
    plt.ylabel('Episode Length')
    plt.title('Episode Length Comparison')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.savefig(os.path.join(output_dir, "episode_lengths.png"), dpi=300)
    plt.close()
    
    # Calculate reward density (reward per step)
    orig_density = [t['total_reward'] / t['length'] for t in original_trajectories]
    refined_density = [t['total_reward'] / t['length'] for t in refined_trajectories]
    
    # Plot reward density
    plt.figure(figsize=(10, 6))
    plt.boxplot([orig_density, refined_density], labels=['Original', method])
    plt.ylabel('Reward per Step')
    plt.title('Reward Density Comparison')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.savefig(os.path.join(output_dir, "reward_density.png"), dpi=300)
    plt.close()
    
    # Calculate summary statistics
    stats = {
        'original': {
            'mean_reward': np.mean([t['total_reward'] for t in original_trajectories]),
            'std_reward': np.std([t['total_reward'] for t in original_trajectories]),
            'mean_length': np.mean(orig_lengths),
            'std_length': np.std(orig_lengths),
            'mean_density': np.mean(orig_density),
            'std_density': np.std(orig_density)
        },
        method.lower(): {
            'mean_reward': np.mean([t['total_reward'] for t in refined_trajectories]),
            'std_reward': np.std([t['total_reward'] for t in refined_trajectories]),
            'mean_length': np.mean(refined_lengths),
            'std_length': np.std(refined_lengths),
            'mean_density': np.mean(refined_density),
            'std_density': np.std(refined_density)
        }
    }
    
    # Calculate improvements
    improvements = {
        'reward': (stats[method.lower()]['mean_reward'] - stats['original']['mean_reward']) / abs(stats['original']['mean_reward']) * 100,
        'length': (stats[method.lower()]['mean_length'] - stats['original']['mean_length']) / abs(stats['original']['mean_length']) * 100,
        'density': (stats[method.lower()]['mean_density'] - stats['original']['mean_density']) / abs(stats['original']['mean_density']) * 100
    }
    
    # Save statistics to file
    with open(os.path.join(output_dir, "statistics.txt"), "w") as f:
        f.write(f"Agent Comparison Statistics\n")
        f.write(f"===========================\n\n")
        
        f.write(f"Original Agent:\n")
        f.write(f"  Mean Reward: {stats['original']['mean_reward']:.2f} ± {stats['original']['std_reward']:.2f}\n")
        f.write(f"  Mean Episode Length: {stats['original']['mean_length']:.2f} ± {stats['original']['std_length']:.2f}\n")
        f.write(f"  Mean Reward Density: {stats['original']['mean_density']:.4f} ± {stats['original']['std_density']:.4f}\n\n")
        
        f.write(f"{method} Agent:\n")
        f.write(f"  Mean Reward: {stats[method.lower()]['mean_reward']:.2f} ± {stats[method.lower()]['std_reward']:.2f}\n")
        f.write(f"  Mean Episode Length: {stats[method.lower()]['mean_length']:.2f} ± {stats[method.lower()]['std_length']:.2f}\n")
        f.write(f"  Mean Reward Density: {stats[method.lower()]['mean_density']:.4f} ± {stats[method.lower()]['std_density']:.4f}\n\n")
        
        f.write(f"Improvements:\n")
        f.write(f"  Reward: {improvements['reward']:.2f}%\n")
        f.write(f"  Episode Length: {improvements['length']:.2f}%\n")
        f.write(f"  Reward Density: {improvements['density']:.2f}%\n")
    
    return stats, improvements

def main():
    args = parse_args()
    
    # Set random seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Create environment
    env = create_environment(args.env)
    
    # Load agents
    original_agent = load_agent(args.original_agent, env)
    refined_agent = load_agent(args.refined_agent, env)
    
    print(f"Loaded original agent from {args.original_agent}")
    print(f"Loaded refined agent from {args.refined_agent}")
    
    # Evaluate original agent
    print("\nEvaluating original agent...")
    original_rewards, original_lengths, original_trajectories = evaluate_agent(
        original_agent, env, args.n_episodes, render=args.record_video
    )
    
    # Evaluate refined agent
    print("\nEvaluating refined agent...")
    refined_rewards, refined_lengths, refined_trajectories = evaluate_agent(
        refined_agent, env, args.n_episodes, render=args.record_video
    )
    
    # Plot comparison
    plot_rewards_comparison(original_rewards, refined_rewards, args.method, args.output_dir)
    
    # Plot reward curves
    plot_reward_curves(original_trajectories, refined_trajectories, args.method, args.output_dir)
    
    # Analyze episode statistics
    stats, improvements = analyze_episode_statistics(original_trajectories, refined_trajectories, args.method, args.output_dir)
    
    # Print summary
    print("\nPerformance Summary:")
    print(f"Original: {np.mean(original_rewards):.2f} ± {np.std(original_rewards):.2f}")
    print(f"{args.method}: {np.mean(refined_rewards):.2f} ± {np.std(refined_rewards):.2f}")
    print(f"Improvement: {improvements['reward']:.2f}%")
    
    print(f"\nResults saved to {args.output_dir}")

if __name__ == "__main__":
    main()
