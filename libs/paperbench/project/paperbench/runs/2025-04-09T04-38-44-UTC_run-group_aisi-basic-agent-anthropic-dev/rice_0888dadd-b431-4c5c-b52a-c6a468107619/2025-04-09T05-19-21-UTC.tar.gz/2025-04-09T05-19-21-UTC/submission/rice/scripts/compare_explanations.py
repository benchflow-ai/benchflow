#!/usr/bin/env python3

import os
import argparse
import numpy as np
import torch
import matplotlib.pyplot as plt
from stable_baselines3 import PPO, SAC

from rice.models.state_mask import ImprovedStateMask, MaskNetwork
from rice.environments.mujoco_envs import create_env
from rice.environments.selfish_mining import SelfishMiningEnv
from rice.environments.network_defense import NetworkDefenseEnv
from rice.environments.auto_driving import AutoDrivingEnv
from rice.utils.fidelity import compute_fidelity_score
from rice.utils.explanation import random_explanation, identify_critical_states

def parse_args():
    parser = argparse.ArgumentParser(description='Compare different explanation methods')
    
    parser.add_argument('--env', type=str, default='hopper', 
                        choices=['hopper', 'walker2d', 'reacher', 'halfcheetah',
                                 'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah',
                                 'selfish_mining', 'network_defense', 'auto_driving'],
                        help='Environment to evaluate on')
    
    parser.add_argument('--agent-path', type=str, required=True,
                        help='Path to agent to evaluate')
    
    parser.add_argument('--output-dir', type=str, default='./explanation_comparison',
                        help='Directory to save results')
    
    parser.add_argument('--train-timesteps', type=int, default=10000,
                        help='Number of timesteps to train explanation methods')
    
    parser.add_argument('--mask-bonus-values', type=str, default='0.0001,0.001,0.01',
                        help='Comma-separated list of mask bonus values (α) to test')
    
    parser.add_argument('--window-fraction', type=float, default=0.1,
                        help='Window fraction for fidelity calculation')
    
    parser.add_argument('--n-trajectories', type=int, default=10,
                        help='Number of trajectories for fidelity calculation')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    return parser.parse_args()

def create_environment(env_name):
    """Create the specified environment"""
    if env_name in ['hopper', 'walker2d', 'reacher', 'halfcheetah', 
                   'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah']:
        return create_env(env_name)
    elif env_name == 'selfish_mining':
        return SelfishMiningEnv()
    elif env_name == 'network_defense':
        return NetworkDefenseEnv()
    elif env_name == 'auto_driving':
        return AutoDrivingEnv()
    else:
        raise ValueError(f"Unknown environment: {env_name}")

def load_agent(agent_path, env):
    """Load an agent"""
    try:
        # Try PPO first
        agent = PPO.load(agent_path, env=env)
        return agent, 'PPO'
    except:
        try:
            # Try SAC if PPO fails
            agent = SAC.load(agent_path, env=env)
            return agent, 'SAC'
        except:
            raise ValueError(f"Failed to load agent from {agent_path} using PPO or SAC")

def collect_trajectory(agent, env, max_steps=1000):
    """Collect a trajectory from the agent"""
    obs, _ = env.reset()
    states = [obs]
    rewards = []
    dones = []
    
    done = False
    step = 0
    
    while not done and step < max_steps:
        action, _ = agent.predict(obs, deterministic=True)
        next_obs, reward, terminated, truncated, _ = env.step(action)
        
        states.append(next_obs)
        rewards.append(reward)
        
        obs = next_obs
        done = terminated or truncated
        dones.append(done)
        step += 1
    
    return np.array(states), np.array(rewards), np.array(dones)

def evaluate_and_visualize_explanations(agent, env, explanation_methods, output_dir, window_fraction=0.1):
    """
    Evaluate and visualize different explanation methods on a trajectory.
    """
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Collect a trajectory
    states, rewards, dones = collect_trajectory(agent, env)
    
    # Create a subplot for each explanation method
    fig, axes = plt.subplots(len(explanation_methods), 1, figsize=(12, 4 * len(explanation_methods)), sharex=True)
    
    if len(explanation_methods) == 1:
        axes = [axes]
    
    # Compute and visualize explanations
    for i, (name, method) in enumerate(explanation_methods.items()):
        # Compute importance scores
        importance_scores = method(states)
        
        # Find the most critical segment
        window_size = int(len(states) * window_fraction)
        if window_size < 1:
            window_size = 1
            
        max_score = -float('inf')
        max_start = 0
        
        for j in range(len(states) - window_size + 1):
            window_score = np.mean(importance_scores[j:j+window_size])
            if window_score > max_score:
                max_score = window_score
                max_start = j
        
        max_end = max_start + window_size
        
        # Plot importance scores
        ax = axes[i]
        ax.plot(importance_scores, label='Importance Score')
        ax.axvspan(max_start, max_end, color='red', alpha=0.3, label=f'Critical Segment [step {max_start}-{max_end}]')
        
        # Plot rewards as a separate y-axis for reference
        ax2 = ax.twinx()
        ax2.plot(rewards, color='green', linestyle='--', label='Reward')
        
        # Add title and labels
        ax.set_title(f'Explanation Method: {name}')
        ax.set_ylabel('Importance Score')
        ax2.set_ylabel('Reward')
        
        if i == len(explanation_methods) - 1:
            ax.set_xlabel('Time Step')
            
        # Add legend
        lines1, labels1 = ax.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax.legend(lines1 + lines2, labels1 + labels2, loc='upper left')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'explanation_comparison.png'), dpi=300)
    plt.close()
    
    print(f"Explanation visualization saved to {os.path.join(output_dir, 'explanation_comparison.png')}")

def main():
    args = parse_args()
    
    # Set random seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    
    # Create environment
    env = create_environment(args.env)
    
    # Load agent
    agent, algorithm = load_agent(args.agent_path, env)
    print(f"Loaded {algorithm} agent from {args.agent_path}")
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Parse mask bonus values
    mask_bonus_values = [float(bonus) for bonus in args.mask_bonus_values.split(',')]
    
    # Prepare results dictionary
    results = {
        'random': [],
    }
    
    for bonus in mask_bonus_values:
        results[f'statemask_alpha_{bonus}'] = []
    
    # Define random explanation method
    def random_explanation_fn(states):
        return random_explanation(states)
    
    # Dictionary of explanation methods
    explanation_methods = {
        'Random': random_explanation_fn
    }
    
    # Train and evaluate different StateMask variants
    for bonus in mask_bonus_values:
        print(f"\nTraining StateMask with α={bonus} for {args.train_timesteps} timesteps...")
        
        # Create and train improved StateMask
        state_mask = ImprovedStateMask(
            target_agent=agent,
            observation_space=env.observation_space,
            action_space=env.action_space,
            mask_bonus=bonus,
        )
        
        mask_net = state_mask.train(env, total_timesteps=args.train_timesteps)
        
        # Save the mask network
        mask_path = os.path.join(args.output_dir, f"{args.env}_mask_alpha_{bonus}.pt")
        torch.save(mask_net.state_dict(), mask_path)
        print(f"Saved mask network to {mask_path}")
        
        # Define explanation function using this mask network
        def statemask_explanation_fn(states, net=mask_net):
            return identify_critical_states(states, net)
        
        # Add to the dictionary of explanation methods
        explanation_methods[f'StateMask (α={bonus})'] = statemask_explanation_fn
    
    # Evaluate fidelity of explanation methods
    print("\nEvaluating explanation fidelity...")
    
    # Compute fidelity for random baseline
    print("Computing fidelity for random explanation...")
    random_fidelity = compute_fidelity_score(
        agent=agent,
        env=env,
        explanation_method=random_explanation_fn,
        trajectory_length=1000,
        window_fraction=args.window_fraction,
        n_trajectories=args.n_trajectories
    )
    results['random'].append(random_fidelity)
    
    # Compute fidelity for each StateMask variant
    for bonus in mask_bonus_values:
        mask_net = MaskNetwork(env.observation_space)
        mask_net.load_state_dict(torch.load(os.path.join(args.output_dir, f"{args.env}_mask_alpha_{bonus}.pt")))
        
        def statemask_explanation_fn(states, net=mask_net):
            return identify_critical_states(states, net)
        
        print(f"Computing fidelity for StateMask with α={bonus}...")
        statemask_fidelity = compute_fidelity_score(
            agent=agent,
            env=env,
            explanation_method=statemask_explanation_fn,
            trajectory_length=1000,
            window_fraction=args.window_fraction,
            n_trajectories=args.n_trajectories
        )
        results[f'statemask_alpha_{bonus}'].append(statemask_fidelity)
    
    # Print results summary
    print("\nExplanation Fidelity Results:")
    print(f"Random explanation: {np.mean(results['random']):.4f}")
    
    for bonus in mask_bonus_values:
        print(f"StateMask (α={bonus}): {np.mean(results[f'statemask_alpha_{bonus}']):.4f}")
    
    # Plot fidelity comparison
    plt.figure(figsize=(10, 6))
    
    # Extract method names and their average fidelity scores
    methods = ['Random'] + [f'StateMask (α={bonus})' for bonus in mask_bonus_values]
    fidelity_scores = [np.mean(results['random'])] + [np.mean(results[f'statemask_alpha_{bonus}']) for bonus in mask_bonus_values]
    
    # Create bar plot
    plt.bar(methods, fidelity_scores)
    plt.ylabel('Fidelity Score')
    plt.title(f'Explanation Method Fidelity Comparison - {args.env}')
    plt.xticks(rotation=45, ha='right')
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    
    plt.savefig(os.path.join(args.output_dir, 'fidelity_comparison.png'), dpi=300)
    plt.close()
    
    print(f"Fidelity comparison plot saved to {os.path.join(args.output_dir, 'fidelity_comparison.png')}")
    
    # Visualize explanations on a sample trajectory
    print("\nVisualizing explanations on a sample trajectory...")
    evaluate_and_visualize_explanations(agent, env, explanation_methods, args.output_dir, args.window_fraction)
    
    # Save results
    np.save(os.path.join(args.output_dir, f"{args.env}_explanation_results.npy"), results)

if __name__ == "__main__":
    main()
