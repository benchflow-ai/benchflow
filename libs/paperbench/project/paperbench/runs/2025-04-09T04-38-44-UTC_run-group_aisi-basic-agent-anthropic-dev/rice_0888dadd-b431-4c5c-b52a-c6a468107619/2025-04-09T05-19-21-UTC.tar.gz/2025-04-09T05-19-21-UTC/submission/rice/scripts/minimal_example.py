#!/usr/bin/env python3

import os
import numpy as np
import torch
import gymnasium as gym
from stable_baselines3 import PPO

from rice.models.state_mask import ImprovedStateMask
from rice.models.rice import RICE
from rice.environments.mujoco_envs import create_env

# Set random seeds for reproducibility
np.random.seed(0)
torch.manual_seed(0)

# Create a simple environment
env_name = 'hopper'
env = create_env(env_name)

def evaluate_agent(agent, env, n_episodes=5):
    """Evaluate an agent's performance"""
    rewards = []
    
    for _ in range(n_episodes):
        obs, _ = env.reset()
        done = False
        total_reward = 0
        
        while not done:
            action, _ = agent.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
            done = terminated or truncated
            
        rewards.append(total_reward)
        print(f"Episode reward: {total_reward:.2f}")
    
    return rewards

def train_and_evaluate():
    # Step 1: Train a basic agent
    print("Step 1: Training a basic agent...")
    agent = PPO(
        policy="MlpPolicy",
        env=env,
        learning_rate=3e-4,
        n_steps=2048,
        batch_size=64,
        n_epochs=10,
        gamma=0.99,
        verbose=1,
        seed=0,
    )
    
    # Train for a short time for demonstration purposes
    agent.learn(total_timesteps=10000)
    
    # Evaluate the agent
    print("\nEvaluating original agent...")
    orig_rewards = evaluate_agent(agent, env)
    print(f"Original agent average reward: {np.mean(orig_rewards):.2f}")
    
    # Step 2: Train the mask network
    print("\nStep 2: Training the mask network...")
    state_mask = ImprovedStateMask(
        target_agent=agent,
        observation_space=env.observation_space,
        action_space=env.action_space,
        mask_bonus=0.01,
    )
    
    mask_net = state_mask.train(env, total_timesteps=5000)
    
    # Step 3: Refine the agent with RICE
    print("\nStep 3: Refining the agent with RICE...")
    rice = RICE(
        pretrained_agent=agent,
        mask_net=mask_net,
        env=env,
        reset_prob=0.5,
        exploration_coef=0.01,
    )
    
    refined_agent = rice.refine(total_timesteps=10000)
    
    # Evaluate the refined agent
    print("\nEvaluating refined agent...")
    refined_rewards = evaluate_agent(refined_agent, env)
    print(f"Refined agent average reward: {np.mean(refined_rewards):.2f}")
    
    # Compare the performance
    improvement = (np.mean(refined_rewards) - np.mean(orig_rewards)) / abs(np.mean(orig_rewards)) * 100
    print(f"\nImprovement: {improvement:.2f}%")
    
    return agent, mask_net, refined_agent

if __name__ == "__main__":
    # Create output directory
    os.makedirs("./minimal_example_results", exist_ok=True)
    
    # Run the example
    agent, mask_net, refined_agent = train_and_evaluate()
    
    # Save the models
    agent.save("./minimal_example_results/original_agent.zip")
    torch.save(mask_net.state_dict(), "./minimal_example_results/mask_network.pt")
    refined_agent.save("./minimal_example_results/refined_agent.zip")
    
    print("\nAll models saved to './minimal_example_results/'")
