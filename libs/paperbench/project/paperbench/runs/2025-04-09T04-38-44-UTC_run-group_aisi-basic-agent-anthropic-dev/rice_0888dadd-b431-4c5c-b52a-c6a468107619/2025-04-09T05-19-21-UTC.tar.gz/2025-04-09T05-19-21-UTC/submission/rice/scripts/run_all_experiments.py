#!/usr/bin/env python3

import os
import argparse
import subprocess
import time
from datetime import datetime

def parse_args():
    parser = argparse.ArgumentParser(description='Run all experiments for RICE paper reproduction')
    
    parser.add_argument('--output-dir', type=str, default='./results',
                        help='Directory to save results')
    
    parser.add_argument('--timesteps', type=int, default=1000000,
                        help='Number of timesteps for base agent training')
    
    parser.add_argument('--refine-timesteps', type=int, default=100000,
                        help='Number of timesteps for each refining method')
    
    parser.add_argument('--environments', type=str, default='all',
                        help='Comma-separated list of environments to run, or "all"')
    
    parser.add_argument('--skip-existing', action='store_true',
                        help='Skip experiments that already have results')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    parser.add_argument('--skip-base-training', action='store_true',
                        help='Skip training base agents (use existing ones)')
    
    parser.add_argument('--skip-mask-training', action='store_true',
                        help='Skip training mask networks (use existing ones)')
    
    parser.add_argument('--skip-refining', action='store_true',
                        help='Skip refining experiments')
    
    parser.add_argument('--skip-hyperparams', action='store_true',
                        help='Skip hyperparameter experiments')
    
    parser.add_argument('--skip-visualization', action='store_true',
                        help='Skip visualization generation')
    
    return parser.parse_args()

def run_command(cmd, desc=None):
    """Run a command and print its output"""
    if desc:
        print(f"\n{'='*80}\n{desc}\n{'='*80}")
    print(f"Running: {cmd}")
    
    try:
        start_time = time.time()
        process = subprocess.run(cmd, shell=True, check=True)
        elapsed_time = time.time() - start_time
        
        print(f"Command completed successfully in {elapsed_time:.2f} seconds")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Command failed with error: {e}")
        return False

def main():
    args = parse_args()
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Determine environments to run
    if args.environments == 'all':
        # All environments from the paper
        environments = [
            'hopper',
            'walker2d',
            'reacher',
            'halfcheetah',
            'sparse_hopper',
            'sparse_walker2d',
            'sparse_halfcheetah',
            'selfish_mining',
            'network_defense',
            'auto_driving'
        ]
    else:
        environments = args.environments.split(',')
    
    # Create a log file
    log_file = os.path.join(args.output_dir, f"experiments_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
    
    with open(log_file, 'w') as f:
        f.write(f"RICE Paper Reproduction Experiments - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Environments: {', '.join(environments)}\n")
        f.write(f"Base agent training timesteps: {args.timesteps}\n")
        f.write(f"Refining timesteps: {args.refine_timesteps}\n")
        f.write(f"Seed: {args.seed}\n\n")
    
    print(f"Running experiments for environments: {', '.join(environments)}")
    print(f"Results will be saved to {args.output_dir}")
    print(f"Log file: {log_file}")
    
    # Track overall progress
    all_experiments = 0
    completed_experiments = 0
    
    # Step 1: Train base agents
    if not args.skip_base_training:
        for env in environments:
            all_experiments += 1
            cmd = (
                f"python -m rice.scripts.train_agent "
                f"--env {env} "
                f"--algorithm PPO "
                f"--timesteps {args.timesteps} "
                f"--output-dir {os.path.join(args.output_dir, 'base_agents')} "
                f"--seed {args.seed}"
            )
            
            desc = f"Training base agent for {env}"
            if run_command(cmd, desc):
                completed_experiments += 1
            
            # Append to log file
            with open(log_file, 'a') as f:
                f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {desc} - {'Completed' if completed_experiments == all_experiments else 'Failed'}\n")
    
    # Step 2: Train mask networks
    if not args.skip_mask_training:
        for env in environments:
            all_experiments += 1
            cmd = (
                f"python -m rice.scripts.train_mask "
                f"--env {env} "
                f"--agent-path {os.path.join(args.output_dir, 'base_agents', env, f'{env}_agent.zip')} "
                f"--mask-save-path {os.path.join(args.output_dir, 'mask_networks')} "
                f"--timesteps {args.refine_timesteps // 2} "
                f"--eval "
                f"--seed {args.seed}"
            )
            
            desc = f"Training mask network for {env}"
            if run_command(cmd, desc):
                completed_experiments += 1
            
            # Append to log file
            with open(log_file, 'a') as f:
                f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {desc} - {'Completed' if completed_experiments == all_experiments else 'Failed'}\n")
    
    # Step 3: Test mask network fidelity
    for env in environments:
        all_experiments += 1
        cmd = (
            f"python -m rice.scripts.test_fidelity "
            f"--env {env} "
            f"--agent-path {os.path.join(args.output_dir, 'base_agents', env, f'{env}_agent.zip')} "
            f"--mask-path {os.path.join(args.output_dir, 'mask_networks', f'{env}_mask.pt')} "
            f"--output-dir {os.path.join(args.output_dir, 'fidelity_results', env)} "
            f"--seed {args.seed}"
        )
        
        desc = f"Testing mask network fidelity for {env}"
        if run_command(cmd, desc):
            completed_experiments += 1
        
        # Append to log file
        with open(log_file, 'a') as f:
            f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {desc} - {'Completed' if completed_experiments == all_experiments else 'Failed'}\n")
    
    # Step 4: Run refining experiments
    if not args.skip_refining:
        for env in environments:
            # Test all refining methods
            methods = ['ppo_finetuning', 'jsrl', 'statemask_reset', 'rice']
            
            for method in methods:
                all_experiments += 1
                cmd = (
                    f"python -m rice.scripts.compare_refining "
                    f"--env {env} "
                    f"--agent-path {os.path.join(args.output_dir, 'base_agents', env, f'{env}_agent.zip')} "
                    f"--mask-path {os.path.join(args.output_dir, 'mask_networks', f'{env}_mask.pt')} "
                    f"--output-dir {os.path.join(args.output_dir, 'refining_results', env)} "
                    f"--timesteps {args.refine_timesteps} "
                    f"--method {method} "
                    f"--seed {args.seed}"
                )
                
                desc = f"Refining {env} with {method}"
                if run_command(cmd, desc):
                    completed_experiments += 1
                
                # Append to log file
                with open(log_file, 'a') as f:
                    f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {desc} - {'Completed' if completed_experiments == all_experiments else 'Failed'}\n")
    
    # Step 5: Run hyperparameter experiments
    if not args.skip_hyperparams:
        # Test p (reset probability) sensitivity
        all_experiments += 1
        cmd = (
            f"python -m rice.scripts.tune_hyperparameters "
            f"--env hopper "
            f"--agent-path {os.path.join(args.output_dir, 'base_agents', 'hopper', 'hopper_agent.zip')} "
            f"--mask-path {os.path.join(args.output_dir, 'mask_networks', 'hopper_mask.pt')} "
            f"--reset-probs 0,0.25,0.5,0.75,1.0 "
            f"--exploration-coef 0.01 "
            f"--output-dir {os.path.join(args.output_dir, 'hyperparameter_results', 'reset_prob')} "
            f"--seed {args.seed}"
        )
        
        desc = "Testing reset probability sensitivity"
        if run_command(cmd, desc):
            completed_experiments += 1
        
        # Append to log file
        with open(log_file, 'a') as f:
            f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {desc} - {'Completed' if completed_experiments == all_experiments else 'Failed'}\n")
        
        # Test λ (exploration coefficient) sensitivity
        all_experiments += 1
        cmd = (
            f"python -m rice.scripts.tune_hyperparameters "
            f"--env hopper "
            f"--agent-path {os.path.join(args.output_dir, 'base_agents', 'hopper', 'hopper_agent.zip')} "
            f"--mask-path {os.path.join(args.output_dir, 'mask_networks', 'hopper_mask.pt')} "
            f"--reset-prob 0.5 "
            f"--exploration-coefs 0,0.001,0.01,0.1 "
            f"--output-dir {os.path.join(args.output_dir, 'hyperparameter_results', 'exploration_coef')} "
            f"--seed {args.seed}"
        )
        
        desc = "Testing exploration coefficient sensitivity"
        if run_command(cmd, desc):
            completed_experiments += 1
        
        # Append to log file
        with open(log_file, 'a') as f:
            f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {desc} - {'Completed' if completed_experiments == all_experiments else 'Failed'}\n")
    
    # Step 6: Generate visualizations
    if not args.skip_visualization:
        all_experiments += 1
        cmd = (
            f"python -m rice.scripts.visualize_results "
            f"--results-dir {args.output_dir} "
            f"--output-dir {os.path.join(args.output_dir, 'figures')} "
            f"--figure-type all"
        )
        
        desc = "Generating visualizations"
        if run_command(cmd, desc):
            completed_experiments += 1
        
        # Append to log file
        with open(log_file, 'a') as f:
            f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {desc} - {'Completed' if completed_experiments == all_experiments else 'Failed'}\n")
        
        # Generate Table 1
        all_experiments += 1
        cmd = (
            f"python -m rice.scripts.generate_table "
            f"--results-dir {args.output_dir} "
            f"--output-dir {os.path.join(args.output_dir, 'table_results')}"
        )
        
        desc = "Generating Table 1"
        if run_command(cmd, desc):
            completed_experiments += 1
        
        # Append to log file
        with open(log_file, 'a') as f:
            f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {desc} - {'Completed' if completed_experiments == all_experiments else 'Failed'}\n")
    
    # Print summary
    print(f"\n{'='*80}")
    print(f"Experiment Summary: {completed_experiments}/{all_experiments} experiments completed successfully")
    print(f"Results saved to {args.output_dir}")
    print(f"Log file: {log_file}")
    
    # Append final summary to log file
    with open(log_file, 'a') as f:
        f.write(f"\n{'='*50}\n")
        f.write(f"Experiment Summary: {completed_experiments}/{all_experiments} experiments completed successfully\n")
        f.write(f"Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

if __name__ == "__main__":
    main()
