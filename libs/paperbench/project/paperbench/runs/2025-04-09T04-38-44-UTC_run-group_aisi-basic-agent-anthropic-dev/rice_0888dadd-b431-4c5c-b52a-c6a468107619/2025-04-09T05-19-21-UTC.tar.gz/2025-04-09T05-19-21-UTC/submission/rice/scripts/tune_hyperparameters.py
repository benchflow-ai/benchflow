#!/usr/bin/env python3

import os
import argparse
import numpy as np
import torch
import matplotlib.pyplot as plt
from stable_baselines3 import PPO, SAC
import itertools
import pandas as pd
from rice.models.state_mask import MaskNetwork
from rice.models.rice import RICE
from rice.environments.mujoco_envs import create_env
from rice.environments.selfish_mining import SelfishMiningEnv
from rice.environments.network_defense import NetworkDefenseEnv
from rice.environments.auto_driving import AutoDrivingEnv

def parse_args():
    parser = argparse.ArgumentParser(description='Tune hyperparameters for RICE')
    
    parser.add_argument('--env', type=str, default='hopper', 
                        choices=['hopper', 'walker2d', 'reacher', 'halfcheetah',
                                 'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah',
                                 'selfish_mining', 'network_defense', 'auto_driving'],
                        help='Environment to tune on')
    
    parser.add_argument('--agent-path', type=str, required=True,
                        help='Path to pre-trained agent')
    
    parser.add_argument('--mask-path', type=str, required=True,
                        help='Path to trained mask network')
    
    parser.add_argument('--output-dir', type=str, default='./hyperparameter_tuning',
                        help='Directory to save results')
    
    parser.add_argument('--timesteps', type=int, default=50000,
                        help='Number of timesteps for each hyperparameter configuration')
    
    parser.add_argument('--n-eval-episodes', type=int, default=10,
                        help='Number of episodes for evaluation')
    
    parser.add_argument('--reset-probs', type=str, default='0,0.25,0.5,0.75,1.0',
                        help='Comma-separated list of reset probabilities (p) to test')
    
    parser.add_argument('--exploration-coefs', type=str, default='0,0.001,0.01,0.1',
                        help='Comma-separated list of exploration coefficients (λ) to test')
    
    parser.add_argument('--seed', type=int, default=0,
                        help='Random seed')
    
    return parser.parse_args()

def create_environment(env_name):
    """Create the specified environment"""
    if env_name in ['hopper', 'walker2d', 'reacher', 'halfcheetah', 
                   'sparse_hopper', 'sparse_walker2d', 'sparse_halfcheetah']:
        return create_env(env_name)
    elif env_name == 'selfish_mining':
        return SelfishMiningEnv()
    elif env_name == 'network_defense':
        return NetworkDefenseEnv()
    elif env_name == 'auto_driving':
        return AutoDrivingEnv()
    else:
        raise ValueError(f"Unknown environment: {env_name}")

def load_agent(agent_path, algorithm, env):
    """Load a pre-trained agent"""
    try:
        # Try PPO first
        agent = PPO.load(agent_path, env=env)
        return agent, 'PPO'
    except:
        try:
            # Try SAC if PPO fails
            agent = SAC.load(agent_path, env=env)
            return agent, 'SAC'
        except:
            raise ValueError(f"Failed to load agent from {agent_path} using PPO or SAC")

def load_mask_network(mask_path, observation_space):
    """Load a trained mask network"""
    # Create mask network with the same architecture
    mask_net = MaskNetwork(observation_space)
    
    # Load weights
    mask_net.load_state_dict(torch.load(mask_path))
    
    return mask_net

def evaluate_agent(agent, env, n_episodes=10):
    """Evaluate an agent's performance"""
    rewards = []
    
    for _ in range(n_episodes):
        obs, _ = env.reset()
        done = False
        total_reward = 0
        
        while not done:
            action, _ = agent.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, _ = env.step(action)
            total_reward += reward
            done = terminated or truncated
            
        rewards.append(total_reward)
    
    return np.mean(rewards), np.std(rewards)

def tune_hyperparameters(agent, mask_net, env, reset_probs, exploration_coefs, timesteps, n_eval_episodes, output_dir):
    """
    Tune hyperparameters for RICE by testing different combinations of
    reset probability (p) and exploration coefficient (λ).
    """
    # Create results directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Create results DataFrame
    results = []
    
    # Test each hyperparameter combination
    for p, lambda_val in itertools.product(reset_probs, exploration_coefs):
        print(f"\nTesting p={p}, λ={lambda_val}")
        
        # Create RICE instance with the current hyperparameters
        rice = RICE(
            pretrained_agent=agent,
            mask_net=mask_net,
            env=env,
            reset_prob=p,
            exploration_coef=lambda_val,
        )
        
        # Refine the agent
        print(f"Refining agent for {timesteps} timesteps...")
        refined_agent = rice.refine(total_timesteps=timesteps)
        
        # Evaluate the refined agent
        mean_reward, std_reward = evaluate_agent(refined_agent, env, n_eval_episodes)
        print(f"Refined agent performance: {mean_reward:.2f} ± {std_reward:.2f}")
        
        # Record results
        results.append({
            'reset_prob': p,
            'exploration_coef': lambda_val,
            'mean_reward': mean_reward,
            'std_reward': std_reward
        })
        
        # Save refined agent
        agent_save_path = os.path.join(output_dir, f"p{p}_lambda{lambda_val}_agent.zip")
        refined_agent.save(agent_save_path)
        print(f"Saved refined agent to {agent_save_path}")
    
    # Convert results to DataFrame
    results_df = pd.DataFrame(results)
    
    # Save results to CSV
    csv_path = os.path.join(output_dir, "hyperparameter_results.csv")
    results_df.to_csv(csv_path, index=False)
    print(f"\nSaved results to {csv_path}")
    
    # Analyze results
    print("\nResults summary:")
    print(results_df.sort_values('mean_reward', ascending=False))
    
    return results_df

def plot_hyperparameter_results(results_df, output_dir):
    """Plot heatmaps for hyperparameter tuning results"""
    # Create pivot tables for heatmaps
    pivot_data = results_df.pivot(index='reset_prob', columns='exploration_coef', values='mean_reward')
    
    # Plot heatmap for mean reward
    plt.figure(figsize=(10, 8))
    sns.heatmap(pivot_data, annot=True, cmap='viridis', fmt='.1f')
    plt.title('Mean Reward for Different Hyperparameter Combinations')
    plt.ylabel('Reset Probability (p)')
    plt.xlabel('Exploration Coefficient (λ)')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'hyperparameter_heatmap.png'), dpi=300)
    plt.close()
    
    # Plot effect of reset probability (p)
    plt.figure(figsize=(10, 6))
    sns.lineplot(data=results_df, x='reset_prob', y='mean_reward', ci='sd', marker='o')
    plt.title('Effect of Reset Probability (p) on Performance')
    plt.xlabel('Reset Probability (p)')
    plt.ylabel('Mean Reward')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.savefig(os.path.join(output_dir, 'reset_prob_effect.png'), dpi=300)
    plt.close()
    
    # Plot effect of exploration coefficient (λ)
    plt.figure(figsize=(10, 6))
    sns.lineplot(data=results_df, x='exploration_coef', y='mean_reward', ci='sd', marker='o')
    plt.title('Effect of Exploration Coefficient (λ) on Performance')
    plt.xlabel('Exploration Coefficient (λ)')
    plt.ylabel('Mean Reward')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.savefig(os.path.join(output_dir, 'exploration_coef_effect.png'), dpi=300)
    plt.close()
    
    print(f"\nPlots saved to {output_dir}")

def main():
    args = parse_args()
    
    # Set random seeds
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    
    # Create environment
    env = create_environment(args.env)
    
    # Load pre-trained agent
    agent, algorithm = load_agent(args.agent_path, None, env)
    print(f"Loaded pre-trained {algorithm} agent from {args.agent_path}")
    
    # Load mask network
    mask_net = load_mask_network(args.mask_path, env.observation_space)
    print(f"Loaded mask network from {args.mask_path}")
    
    # Parse hyperparameter ranges
    reset_probs = [float(p) for p in args.reset_probs.split(',')]
    exploration_coefs = [float(c) for c in args.exploration_coefs.split(',')]
    
    print(f"Testing reset probabilities (p): {reset_probs}")
    print(f"Testing exploration coefficients (λ): {exploration_coefs}")
    
    # Create output directory
    output_dir = os.path.join(args.output_dir, args.env)
    os.makedirs(output_dir, exist_ok=True)
    
    # Evaluate the original agent
    original_mean, original_std = evaluate_agent(agent, env, args.n_eval_episodes)
    print(f"Original agent performance: {original_mean:.2f} ± {original_std:.2f}")
    
    # Tune hyperparameters
    results_df = tune_hyperparameters(
        agent=agent,
        mask_net=mask_net,
        env=env,
        reset_probs=reset_probs,
        exploration_coefs=exploration_coefs,
        timesteps=args.timesteps,
        n_eval_episodes=args.n_eval_episodes,
        output_dir=output_dir
    )
    
    # Determine best hyperparameters
    best_row = results_df.loc[results_df['mean_reward'].idxmax()]
    best_p = best_row['reset_prob']
    best_lambda = best_row['exploration_coef']
    best_reward = best_row['mean_reward']
    
    print(f"\nBest hyperparameters:")
    print(f"  Reset probability (p): {best_p}")
    print(f"  Exploration coefficient (λ): {best_lambda}")
    print(f"  Mean reward: {best_reward:.2f}")
    print(f"  Improvement over original: {(best_reward - original_mean) / abs(original_mean) * 100:.2f}%")
    
    # Plot results
    try:
        import seaborn as sns
        plot_hyperparameter_results(results_df, output_dir)
    except ImportError:
        print("Seaborn not installed. Skipping plots.")
    
    # Save best hyperparameters
    with open(os.path.join(output_dir, "best_hyperparameters.txt"), "w") as f:
        f.write(f"Original agent performance: {original_mean:.2f} ± {original_std:.2f}\n")
        f.write(f"Best hyperparameters:\n")
        f.write(f"  Reset probability (p): {best_p}\n")
        f.write(f"  Exploration coefficient (λ): {best_lambda}\n")
        f.write(f"  Mean reward: {best_reward:.2f}\n")
        f.write(f"  Improvement over original: {(best_reward - original_mean) / abs(original_mean) * 100:.2f}%\n")

if __name__ == "__main__":
    main()
