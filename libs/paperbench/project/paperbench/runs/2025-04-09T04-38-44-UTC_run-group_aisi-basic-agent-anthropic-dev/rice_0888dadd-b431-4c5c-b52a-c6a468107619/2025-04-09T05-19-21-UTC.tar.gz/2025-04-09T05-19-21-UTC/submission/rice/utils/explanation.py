import torch
import numpy as np
import random

def random_explanation(states):
    """
    Random baseline explanation method.
    
    Returns randomly generated importance scores for each state.
    """
    return np.random.random(len(states))

def identify_critical_states(states, mask_net, device="cpu"):
    """
    Identify critical states using a trained mask network.
    
    Args:
        states: List or array of states
        mask_net: Trained mask network
        device: Device to run the mask network on
        
    Returns:
        importance_scores: Array of importance scores for each state
    """
    # Convert states to tensor
    if not isinstance(states, torch.Tensor):
        states_tensor = torch.FloatTensor(states).to(device)
    else:
        states_tensor = states.to(device)
    
    # Get mask probabilities
    with torch.no_grad():
        mask_probs = mask_net(states_tensor)
        
        # Importance scores are (1 - mask_prob)
        # Higher scores mean the state is more critical
        importance_scores = 1 - mask_probs.squeeze().cpu().numpy()
        
    return importance_scores

def sample_from_mixed_distribution(critical_states, original_reset_fn, p=0.5):
    """
    Sample from a mixed initial state distribution.
    
    With probability p, return a critical state.
    With probability (1-p), use the original reset function.
    
    Args:
        critical_states: List of critical states to sample from
        original_reset_fn: Original reset function of the environment
        p: Probability of sampling a critical state
        
    Returns:
        A sampled state
    """
    if len(critical_states) == 0 or random.random() >= p:
        # Sample from original distribution
        return original_reset_fn()
    else:
        # Sample a critical state
        return random.choice(critical_states)

def sliding_window(importance_scores, window_size):
    """
    Use a sliding window to find the most critical segment.
    
    Args:
        importance_scores: Array of importance scores
        window_size: Size of the sliding window
        
    Returns:
        start_idx, end_idx: Start and end indices of the most critical segment
    """
    if len(importance_scores) <= window_size:
        return 0, len(importance_scores)
    
    max_score = -float('inf')
    max_start = 0
    
    for i in range(len(importance_scores) - window_size + 1):
        window_score = np.mean(importance_scores[i:i+window_size])
        if window_score > max_score:
            max_score = window_score
            max_start = i
            
    return max_start, max_start + window_size
