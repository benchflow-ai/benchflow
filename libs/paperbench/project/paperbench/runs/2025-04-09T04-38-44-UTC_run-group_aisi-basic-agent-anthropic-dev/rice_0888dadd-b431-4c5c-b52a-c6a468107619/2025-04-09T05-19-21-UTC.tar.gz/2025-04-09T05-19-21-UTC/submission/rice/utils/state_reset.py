import numpy as np
import gymnasium as gym
from typing import Dict, Any, List, Optional, Tuple, Union

class StateResetWrapper(gym.Wrapper):
    """
    A wrapper that allows resetting an environment to a specific state.
    
    This is useful for implementing RICE's mixed initial state distribution.
    Different environments handle state resetting differently, so this wrapper
    provides a unified interface for resetting to specific states.
    """
    def __init__(self, env):
        super(StateResetWrapper, self).__init__(env)
        self.initial_state = None
        self.initial_state_set = False
        
    def reset(self, *, seed: Optional[int] = None, options: Optional[Dict[str, Any]] = None):
        """
        Reset the environment.
        
        If options['state'] is provided, attempts to reset to that state.
        Otherwise, resets to the default initial state.
        """
        if options is not None and 'state' in options:
            # Try to reset to the provided state
            return self.reset_to_state(options['state'])
        else:
            # Use the environment's normal reset
            obs, info = self.env.reset(seed=seed)
            
            # Store the initial state if we haven't done so already
            if not self.initial_state_set:
                try:
                    self.initial_state = self.get_state()
                    self.initial_state_set = True
                except NotImplementedError:
                    # Environment doesn't support get_state
                    pass
                
            return obs, info
    
    def reset_to_state(self, state):
        """Reset the environment to the given state"""
        # Try different reset methods depending on environment type
        try:
            return self._try_reset_methods(state)
        except Exception as e:
            print(f"Warning: Failed to reset to state: {e}")
            # Fall back to regular reset if state resetting fails
            return self.env.reset()
    
    def _try_reset_methods(self, state):
        """Try different methods to reset environment state"""
        # Method 1: Use environment's set_state method if available
        if hasattr(self.env, 'set_state'):
            self.env.set_state(state)
            # Return the state as observation
            if hasattr(state, 'observation'):
                return state.observation, {}
            elif isinstance(state, dict) and 'observation' in state:
                return state['observation'], {}
            else:
                return self._get_obs_from_state(state), {}
        
        # Method 2: Try to use MuJoCo-specific methods
        if hasattr(self.env.unwrapped, 'model') and hasattr(self.env.unwrapped, 'sim'):
            try:
                self.env.reset()
                # For MuJoCo, state is typically [qpos, qvel]
                if isinstance(state, tuple) and len(state) == 2:
                    qpos, qvel = state
                    self.env.unwrapped.set_state(qpos, qvel)
                elif hasattr(state, 'qpos') and hasattr(state, 'qvel'):
                    self.env.unwrapped.set_state(state.qpos, state.qvel)
                else:
                    # Try to unpack the state if it's a numpy array
                    if isinstance(state, np.ndarray):
                        if len(state.shape) == 1:
                            # Try to split the state
                            nq = self.env.unwrapped.model.nq
                            if len(state) >= nq:
                                qpos, qvel = state[:nq], state[nq:nq+self.env.unwrapped.model.nv]
                                self.env.unwrapped.set_state(qpos, qvel)
                
                # Get observation after setting state
                return self.env.unwrapped._get_obs(), {}
            except Exception as e:
                print(f"MuJoCo state reset failed: {e}")
                pass
        
        # Method 3: Check if environment has a custom reset_to_state method
        if hasattr(self.env.unwrapped, 'reset_to_state'):
            return self.env.unwrapped.reset_to_state(state)
        
        # Method 4: Use our own implementation for simple environments
        return self._custom_reset_to_state(state)
    
    def _custom_reset_to_state(self, state):
        """Custom implementation of reset_to_state for simple environments"""
        # Reset the environment first
        self.env.reset()
        
        # Check if state is a simple observation (e.g., numpy array)
        if isinstance(state, np.ndarray):
            # For simple environments, we might be able to just return the state
            # and rely on the environment's dynamics to evolve from there
            return state, {}
        
        # If state is a dictionary with full environment state
        if isinstance(state, dict) and 'observation' in state:
            # Some environments allow setting internal state
            for key, value in state.items():
                if key != 'observation' and hasattr(self.env.unwrapped, key):
                    setattr(self.env.unwrapped, key, value)
            
            return state['observation'], {}
        
        # If we reach here, we don't know how to reset to this state
        raise NotImplementedError(f"Don't know how to reset to state of type {type(state)}")
    
    def _get_obs_from_state(self, state):
        """Extract observation from state"""
        # For numpy array states, assume the state is the observation
        if isinstance(state, np.ndarray):
            return state
        
        # For tuple states, assume first element is the observation
        if isinstance(state, tuple) and len(state) > 0:
            return state[0]
        
        # For dictionary states, look for 'observation' key
        if isinstance(state, dict) and 'observation' in state:
            return state['observation']
        
        # Default: return state as is
        return state
    
    def get_state(self):
        """Get the current environment state"""
        # Try different methods to get state depending on environment type
        
        # Method 1: Use environment's get_state method if available
        if hasattr(self.env, 'get_state'):
            return self.env.get_state()
        
        # Method 2: Try to use MuJoCo-specific methods
        if hasattr(self.env.unwrapped, 'sim'):
            try:
                qpos = self.env.unwrapped.sim.data.qpos.copy()
                qvel = self.env.unwrapped.sim.data.qvel.copy()
                return (qpos, qvel)
            except:
                pass
        
        # Method 3: Check if environment has a custom get_state method
        if hasattr(self.env.unwrapped, 'get_state'):
            return self.env.unwrapped.get_state()
        
        # Method 4: For environments without explicit state, use observation
        obs = self.env.unwrapped._get_obs() if hasattr(self.env.unwrapped, '_get_obs') else None
        
        # If we can't get state, raise error
        if obs is None:
            raise NotImplementedError("Environment doesn't support get_state")
        
        return obs


class MixedInitialStateEnv(StateResetWrapper):
    """
    Environment wrapper that implements RICE's mixed initial state distribution.
    
    With probability p, resets to a critical state.
    With probability (1-p), resets to a default initial state.
    """
    def __init__(self, env, critical_states=None, reset_prob=0.5):
        super(MixedInitialStateEnv, self).__init__(env)
        self.critical_states = critical_states or []
        self.reset_prob = reset_prob
    
    def reset(self, *, seed: Optional[int] = None, options: Optional[Dict[str, Any]] = None):
        """
        Reset with probability of using a critical state.
        """
        # With probability p, reset to a critical state
        if len(self.critical_states) > 0 and np.random.random() < self.reset_prob:
            # Sample a random critical state
            state = np.random.choice(self.critical_states)
            return self.reset_to_state(state)
        else:
            # Reset to default initial state
            return super().reset(seed=seed, options=options)
    
    def add_critical_state(self, state):
        """Add a critical state to the collection"""
        self.critical_states.append(state)
    
    def add_critical_states(self, states):
        """Add multiple critical states to the collection"""
        self.critical_states.extend(states)
    
    def clear_critical_states(self):
        """Clear all critical states"""
        self.critical_states = []
