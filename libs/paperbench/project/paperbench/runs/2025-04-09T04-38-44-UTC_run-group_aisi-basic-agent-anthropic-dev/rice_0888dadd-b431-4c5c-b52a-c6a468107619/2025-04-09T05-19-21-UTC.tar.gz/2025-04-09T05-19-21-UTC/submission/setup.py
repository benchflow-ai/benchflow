
from setuptools import setup, find_packages

setup(
    name="rice",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "torch",
        "gymnasium",
        "stable-baselines3",
        "matplotlib",
    ],
    description="RICE: Breaking Through the Training Bottlenecks of Reinforcement Learning with Explanation",
)
