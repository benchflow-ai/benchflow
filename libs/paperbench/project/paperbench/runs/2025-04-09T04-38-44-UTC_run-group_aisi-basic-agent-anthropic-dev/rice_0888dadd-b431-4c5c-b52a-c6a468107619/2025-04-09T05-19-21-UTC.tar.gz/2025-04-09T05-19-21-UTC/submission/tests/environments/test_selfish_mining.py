import os
import sys
import unittest
import numpy as np
import gymnasium as gym

from rice.environments.selfish_mining import SelfishMiningEnv

class TestSelfishMiningEnvironment(unittest.TestCase):
    def setUp(self):
        # Create environment
        self.env = SelfishMiningEnv()
    
    def tearDown(self):
        # Close environment
        self.env.close()
    
    def test_initialization(self):
        # Test that environment is initialized correctly
        self.assertIsInstance(self.env, SelfishMiningEnv)
        
        # Check spaces
        self.assertIsInstance(self.env.observation_space, gym.spaces.Box)
        self.assertIsInstance(self.env.action_space, gym.spaces.Discrete)
        
        # Check action space size (should be 2: adopt or override)
        self.assertEqual(self.env.action_space.n, 2)
        
        # Check initial state
        self.assertEqual(self.env.lead, 0)
        self.assertEqual(self.env.fork, 0)
        self.assertEqual(self.env.next_to_reveal, 0)
        self.assertEqual(self.env.selfish_blocks, 0)
        self.assertEqual(self.env.honest_blocks, 0)
        self.assertEqual(self.env.steps, 0)
    
    def test_reset(self):
        # Take some steps to change the state
        self.env.step(0)
        self.env.step(1)
        
        # Reset the environment
        obs, _ = self.env.reset()
        
        # Check that state is reset
        self.assertEqual(self.env.lead, 0)
        self.assertEqual(self.env.fork, 0)
        self.assertEqual(self.env.next_to_reveal, 0)
        self.assertEqual(self.env.selfish_blocks, 0)
        self.assertEqual(self.env.honest_blocks, 0)
        self.assertEqual(self.env.steps, 0)
        
        # Check observation shape
        self.assertEqual(obs.shape, (3,))
    
    def test_step(self):
        # Test taking a step
        obs, _ = self.env.reset()
        
        # Take a step
        next_obs, reward, terminated, truncated, info = self.env.step(0)  # Adopt
        
        # Check that next_obs has the right shape
        self.assertEqual(next_obs.shape, (3,))
        
        # Check that reward is a scalar
        self.assertIsInstance(reward, float)
        
        # Check that terminated and truncated are booleans
        self.assertIsInstance(terminated, bool)
        self.assertIsInstance(truncated, bool)
        
        # Check that info is a dictionary
        self.assertIsInstance(info, dict)
        
        # Check that steps are incremented
        self.assertEqual(self.env.steps, 1)
    
    def test_episode_termination(self):
        # Test that episode terminates after max_steps
        obs, _ = self.env.reset()
        
        # Take steps until termination
        terminated = False
        truncated = False
        steps = 0
        
        while not (terminated or truncated) and steps < 2000:  # Safety limit
            next_obs, reward, terminated, truncated, info = self.env.step(0)  # Adopt
            steps += 1
        
        # Check that episode terminated
        self.assertTrue(terminated or truncated)
        
        # Check that steps match max_steps or are less than safety limit
        self.assertTrue(steps <= 2000)

if __name__ == '__main__':
    unittest.main()
