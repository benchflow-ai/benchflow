import os
import sys
import unittest
import numpy as np
import torch
import gymnasium as gym
from stable_baselines3 import PPO

from rice.models.state_mask import MaskNetwork, ImprovedStateMask

class TestMaskNetwork(unittest.TestCase):
    def setUp(self):
        # Create a simple observation space for testing
        self.observation_space = gym.spaces.Box(
            low=-1.0, high=1.0, shape=(4,), dtype=np.float32
        )
        
        # Initialize mask network
        self.mask_net = MaskNetwork(self.observation_space)
    
    def test_initialization(self):
        # Test that the network is initialized correctly
        self.assertIsInstance(self.mask_net, MaskNetwork)
        self.assertIsInstance(self.mask_net.network, torch.nn.Sequential)
    
    def test_forward_pass(self):
        # Test forward pass with a single observation
        obs = np.array([0.1, 0.2, 0.3, 0.4], dtype=np.float32)
        output = self.mask_net(obs)
        
        # Check that output is a tensor
        self.assertIsInstance(output, torch.Tensor)
        
        # Check that output has the right shape
        self.assertEqual(output.shape, torch.Size([1, 1]))
        
        # Check that output is between 0 and 1 (probability)
        self.assertTrue(0 <= output.item() <= 1)
    
    def test_batch_forward_pass(self):
        # Test forward pass with a batch of observations
        batch_size = 5
        batch_obs = np.random.uniform(-1, 1, size=(batch_size, 4)).astype(np.float32)
        output = self.mask_net(batch_obs)
        
        # Check that output has the right shape
        self.assertEqual(output.shape, torch.Size([batch_size, 1]))
        
        # Check that all outputs are between 0 and 1
        self.assertTrue(torch.all((output >= 0) & (output <= 1)))
    
    def test_sample_action(self):
        # Test the sample_action method
        obs = np.array([0.1, 0.2, 0.3, 0.4], dtype=np.float32)
        
        # Test deterministic action
        action, prob = self.mask_net.sample_action(obs, deterministic=True)
        
        # Check that action is a tensor
        self.assertIsInstance(action, torch.Tensor)
        
        # Check that action is binary (0 or 1)
        self.assertTrue(action.item() in [0.0, 1.0])
        
        # Test stochastic action
        action, prob = self.mask_net.sample_action(obs, deterministic=False)
        
        # Check that action is binary (0 or 1)
        self.assertTrue(action.item() in [0.0, 1.0])
        
        # Check that probability is between 0 and 1
        self.assertTrue(0 <= prob.item() <= 1)

class TestImprovedStateMask(unittest.TestCase):
    def setUp(self):
        # Create a simple environment for testing
        self.env = gym.make('CartPole-v1')
        
        # Train a simple agent for testing
        self.agent = PPO('MlpPolicy', self.env, verbose=0, seed=0)
        self.agent.learn(total_timesteps=100)  # Just a few steps
        
        # Initialize improved state mask
        self.state_mask = ImprovedStateMask(
            target_agent=self.agent,
            observation_space=self.env.observation_space,
            action_space=self.env.action_space,
            mask_bonus=0.01
        )
    
    def test_initialization(self):
        # Test that the state mask is initialized correctly
        self.assertIsInstance(self.state_mask, ImprovedStateMask)
        self.assertIsInstance(self.state_mask.mask_net, MaskNetwork)
        self.assertEqual(self.state_mask.mask_bonus, 0.01)
    
    def test_explain(self):
        # Generate a small batch of states
        obs, _ = self.env.reset()
        states = [obs]
        
        for _ in range(5):
            action, _ = self.agent.predict(obs, deterministic=False)
            obs, _, terminated, truncated, _ = self.env.step(action)
            states.append(obs)
            
            if terminated or truncated:
                break
        
        # Test the explain method
        importance_scores = self.state_mask.explain(states)
        
        # Check that importance scores have the right shape
        self.assertEqual(len(importance_scores), len(states))
        
        # Check that importance scores are between 0 and 1
        self.assertTrue(np.all((importance_scores >= 0) & (importance_scores <= 1)))

if __name__ == '__main__':
    unittest.main()
