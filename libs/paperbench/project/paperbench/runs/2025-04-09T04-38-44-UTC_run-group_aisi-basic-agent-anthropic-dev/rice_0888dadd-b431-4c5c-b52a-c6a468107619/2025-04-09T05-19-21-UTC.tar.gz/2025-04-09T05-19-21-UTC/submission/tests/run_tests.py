#!/usr/bin/env python3

import unittest
import argparse
import sys
from pathlib import Path

def parse_args():
    parser = argparse.ArgumentParser(description='Run tests for RICE')
    
    parser.add_argument('--test-dir', type=str, default='tests',
                        help='Directory containing tests')
    
    parser.add_argument('--pattern', type=str, default='test_*.py',
                        help='Pattern to match test files')
    
    parser.add_argument('--verbose', '-v', action='store_true',
                        help='Run tests in verbose mode')
    
    parser.add_argument('--category', type=str, default=None,
                        choices=['models', 'environments', 'utils'],
                        help='Only run tests in a specific category')
    
    return parser.parse_args()

def discover_and_run_tests(test_dir, pattern, verbose=False, category=None):
    # Build test suite
    loader = unittest.TestLoader()
    
    if category:
        # Only run tests in the specified category
        start_dir = Path(test_dir) / category
    else:
        # Run all tests
        start_dir = test_dir
    
    suite = loader.discover(str(start_dir), pattern=pattern)
    
    # Run tests
    verbosity = 2 if verbose else 1
    runner = unittest.TextTestRunner(verbosity=verbosity)
    result = runner.run(suite)
    
    # Return success/failure
    return result.wasSuccessful()

def main():
    args = parse_args()
    
    success = discover_and_run_tests(
        test_dir=args.test_dir,
        pattern=args.pattern,
        verbose=args.verbose,
        category=args.category
    )
    
    # Return appropriate exit code
    sys.exit(0 if success else 1)

if __name__ == '__main__':
    main()
