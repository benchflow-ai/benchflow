import os
import sys
import argparse
import json
import pandas as pd

# Ensure src is in path if running script directly
try:
    script_dir = os.path.dirname(__file__)
except NameError:
    script_dir = '/home/submission/scripts' # Fallback
sys.path.append(os.path.abspath(os.path.join(script_dir, '..', 'src')))

try:
    from rice import train_rice
    from baselines import train_ppo_finetune, train_statemask_r
    # NOTE: JSRL requires external code as per Appendix C.1
    # (https://github.com/steventango/jumpstart-rl).
    # It won't be directly executed here, just noted as a baseline.
    # from fidelity import load_policy # If needed for evaluation step later
except ImportError as e:
    print(f"Error importing from rice/baselines: {e}. Using dummies.")
    def train_rice(*args, **kwargs):
        print("[Dummy] train_rice called.", flush=True)
        save_path = kwargs.get('save_path')
        if save_path: print(f"[Dummy] Would save to {save_path}")
    def train_ppo_finetune(*args, **kwargs):
        print("[Dummy] train_ppo_finetune called.", flush=True)
        save_path = kwargs.get('save_path')
        if save_path: print(f"[Dummy] Would save to {save_path}")
    def train_statemask_r(*args, **kwargs):
        print("[Dummy] train_statemask_r called.", flush=True)
        save_path = kwargs.get('save_path')
        if save_path: print(f"[Dummy] Would save to {save_path}")

# Default hyperparameters from paper (Appendix C.3 Table 3)
DEFAULT_RICE_PARAMS = {
    "Hopper-v3":      {"p_critical": 0.25, "lambda_intrinsic": 0.001},
    "Walker2d-v3":    {"p_critical": 0.25, "lambda_intrinsic": 0.01},
    "Reacher-v2":     {"p_critical": 0.50, "lambda_intrinsic": 0.001},
    "HalfCheetah-v3": {"p_critical": 0.50, "lambda_intrinsic": 0.01},
    "SelfishMining":  {"p_critical": 0.25, "lambda_intrinsic": 0.001},
    "CageChallenge2": {"p_critical": 0.50, "lambda_intrinsic": 0.01},
    "AutoDriving":    {"p_critical": 0.25, "lambda_intrinsic": 0.01},
    # Sparse params (guessed, use if needed for Fig 2)
    "SparseHopper-v0": {"p_critical": 0.25, "lambda_intrinsic": 0.01},
    "SparseHalfCheetah-v0": {"p_critical": 0.50, "lambda_intrinsic": 0.01},
    "Default":        {"p_critical": 0.25, "lambda_intrinsic": 0.01} # Fallback
}

# Assumed default refinement timesteps (needs tuning per environment)
DEFAULT_REFINE_TIMESTEPS = 100_000 # Placeholder

# Default LR for fine-tuning baselines
DEFAULT_FINETUNE_LR = 1e-5


if __name__ == "__main__":
    # Define directories
    try: script_dir = os.path.dirname(__file__)
    except NameError: script_dir = '/home/submission/scripts'
    default_model_root = os.path.abspath(os.path.join(script_dir, '..', 'models'))
    default_pretrained_dir = os.path.join(default_model_root, 'pretrained')
    default_mask_dir = os.path.join(default_model_root, 'mask_nets')
    default_refined_dir = os.path.join(default_model_root, 'refined')
    default_results_dir = os.path.abspath(os.path.join(script_dir, '..', 'results'))

    parser = argparse.ArgumentParser(description="Run Refinement Experiments (II, III, IV)")
    parser.add_argument("--env", help="Environment ID", type=str, required=True)
    parser.add_argument("--seed", help="Random seed", type=int, default=42)
    # Paths
    parser.add_argument("--pretrained-path", help="Path to the pre-trained agent (.zip)", type=str, default=None)
    parser.add_argument("--pretrained-algo", help="Algorithm of the pre-trained agent (PPO or SAC)", type=str, default="PPO")
    parser.add_argument("--mask-path", help="Path to the trained mask network (.zip). If omitted for rice/statemask_r, uses default path. If 'none', forces random mask for RICE.", type=str, default=None)
    parser.add_argument("--results-dir", help="Directory to save evaluation results (e.g., learning curves)", type=str, default=default_results_dir)
    parser.add_argument("--refined-save-dir", help="Directory to save the refined models", type=str, default=default_refined_dir)
    # Experiment selection
    parser.add_argument("--methods", help="Comma-separated list of methods (rice, ppo_finetune, statemask_r, jsrl, rice_nomask)", type=str, default="rice,ppo_finetune,statemask_r,rice_nomask")
    # Hyperparameters
    parser.add_argument("--timesteps", help="Total refinement timesteps", type=int, default=DEFAULT_REFINE_TIMESTEPS)
    parser.add_argument("--p-critical", help="Override RICE p_critical", type=float, default=None)
    parser.add_argument("--lambda-intrinsic", help="Override RICE lambda_intrinsic", type=float, default=None)
    parser.add_argument("--finetune-lr", help="Learning rate for PPO fine-tuning and StateMask-R", type=float, default=DEFAULT_FINETUNE_LR)
    # Other
    parser.add_argument("--n-envs", help="Number of parallel environments", type=int, default=4)
    parser.add_argument("--ppo-kwargs", help="JSON string of PPO kwargs for refinement", type=str, default='{}')

    args, unknown = parser.parse_known_args()

    # --- Input Validation and Path Setup ---
    pretrained_path = args.pretrained_path
    if not pretrained_path:
        pretrained_filename = f"{args.env}_{args.pretrained_algo.lower()}_pretrained.zip"
        pretrained_path = os.path.join(default_pretrained_dir, pretrained_filename)
        print(f"Note: --pretrained-path not provided, assuming default: {pretrained_path}")

    # Handle mask_path: None means use default, 'none' means force no mask (for rice_nomask)
    mask_path = args.mask_path
    force_no_mask = False
    if mask_path is None:
        try:
            module_dir = os.path.dirname('/home/submission/scripts/run_refinement.py') # Use absolute path
            if module_dir not in sys.path: sys.path.insert(0, module_dir)
            from train_mask import DEFAULT_ALPHAS
            alpha = DEFAULT_ALPHAS.get(args.env, DEFAULT_ALPHAS["Default"])
        except (ImportError, KeyError): alpha = 0.001 # Fallback
        mask_filename = f"{args.env}_mask_net_alpha{alpha}_seed{args.seed}.zip"
        mask_path = os.path.join(default_mask_dir, mask_filename)
        print(f"Note: --mask-path not provided, assuming default: {mask_path}")
    elif mask_path.lower() == 'none':
        print("Note: --mask-path set to 'none'. Mask network will not be used.")
        force_no_mask = True
        mask_path = None # Set path to None internally

    env_rice_params = DEFAULT_RICE_PARAMS.get(args.env, DEFAULT_RICE_PARAMS["Default"])
    p_critical = args.p_critical if args.p_critical is not None else env_rice_params["p_critical"]
    lambda_intrinsic = args.lambda_intrinsic if args.lambda_intrinsic is not None else env_rice_params["lambda_intrinsic"]

    try: ppo_kwargs_dict = json.loads(args.ppo_kwargs) if args.ppo_kwargs else {}
    except json.JSONDecodeError: ppo_kwargs_dict = {}

    methods_to_run = [m.strip().lower() for m in args.methods.split(',')]
    os.makedirs(args.results_dir, exist_ok=True)
    os.makedirs(args.refined_save_dir, exist_ok=True)

    # --- Log Run Configuration --- #
    print("--- Running Refinement Experiment --- ", flush=True)
    print(f" Env: {args.env}, Seed: {args.seed}", flush=True)
    print(f" Pretrained: {pretrained_path} ({args.pretrained_algo})", flush=True)
    print(f" Mask Net Path: {mask_path if not force_no_mask else 'None (Forced)'}", flush=True)
    print(f" Methods: {methods_to_run}", flush=True)
    print(f" Timesteps: {args.timesteps}", flush=True)
    print(f" N Envs: {args.n_envs}", flush=True)
    print(f" RICE Params: p={p_critical}, lambda={lambda_intrinsic}", flush=True)
    print(f" Baseline LR: {args.finetune_lr}", flush=True)
    print(f" PPO Kwargs: {ppo_kwargs_dict}", flush=True)
    print(f" Save Dir (Models): {args.refined_save_dir}", flush=True)
    print(f" Save Dir (Logs/Results): {args.results_dir}", flush=True)
    print(f"--- Starting setup... (Execution Skipped) ---", flush=True)

    # --- Check prerequisites --- #
    pretrained_exists = os.path.exists(pretrained_path)
    mask_needed = any(m in methods_to_run for m in ["rice", "statemask_r"])
    mask_exists = not force_no_mask and mask_path and os.path.exists(mask_path)

    if not pretrained_exists:
        print(f"Error: Pretrained model not found: {pretrained_path}. Cannot run refinement.")
        sys.exit(1) # Exit if base model missing
    if mask_needed and not mask_exists:
        print(f"Warning: Mask network not found ({mask_path}) or forced off. Cannot run methods requiring mask.")
        methods_to_run = [m for m in methods_to_run if m not in ["rice", "statemask_r"]]
        print(f"Updated methods to run: {methods_to_run}")
    if "rice_nomask" in methods_to_run and not mask_needed:
         print("Note: 'rice_nomask' implies RICE framework without mask guidance.")

    # --- Run selected methods (Commented Out) --- #
    execution_enabled = False # Control flag
    # if execution_enabled:
    #     for method in methods_to_run:
    #         print(f"--- Running Method: {{method}} ---", flush=True) # Corrected print
    #         refined_model_save_path = os.path.join(args.refined_save_dir, f"{{args.env}}_{{method}}_seed{{args.seed}}.zip")
    #         log_folder = os.path.join(args.results_dir, f"{{method}}_logs")
    #
    #         try:
    #             current_mask_path = None # Default to no mask (for rice_nomask, ppo_finetune)
    #             if method == "rice": current_mask_path = mask_path
    #             if method == "statemask_r": current_mask_path = mask_path
    #
    #             if method == "rice" or method == "rice_nomask":
    #                 # Pass mask_path=None for rice_nomask
    #                 train_rice(
    #                     env_id=args.env, pretrained_policy_path=pretrained_path,
    #                     pretrained_policy_algo=args.pretrained_algo, mask_network_path=current_mask_path,
    #                     save_path=refined_model_save_path, p_critical=p_critical,
    #                     lambda_intrinsic=lambda_intrinsic, total_timesteps=args.timesteps,
    #                     n_envs=args.n_envs, seed=args.seed, ppo_kwargs=ppo_kwargs_dict,
    #                     log_folder=log_folder
    #                 )
    #             elif method == "ppo_finetune":
    #                 train_ppo_finetune(
    #                     env_id=args.env, pretrained_policy_path=pretrained_path,
    #                     pretrained_algo=args.pretrained_algo, save_path=refined_model_save_path,
    #                     total_timesteps=args.timesteps, n_envs=args.n_envs, seed=args.seed,
    #                     learning_rate=args.finetune_lr, ppo_kwargs=ppo_kwargs_dict,
    #                     log_folder=log_folder
    #                 )
    #             elif method == "statemask_r":
    #                 train_statemask_r(
    #                     env_id=args.env, pretrained_policy_path=pretrained_path,
    #                     pretrained_algo=args.pretrained_algo, mask_network_path=current_mask_path,
    #                     save_path=refined_model_save_path, total_timesteps=args.timesteps,
    #                     n_envs=args.n_envs, seed=args.seed, learning_rate=args.finetune_lr,
    #                     ppo_kwargs=ppo_kwargs_dict, log_folder=log_folder
    #                 )
    #             elif method == "jsrl":
    #                 print("JSRL requires external code. Skipping.")
    #             else:
    #                 print(f"Warning: Unknown method '{{method}}'. Skipping.")
    #
    #         except ImportError as imp_err:
    #              print(f"Skipping method {{method}} due to import error: {{imp_err}}")
    #         except Exception as e:
    #              print(f"Error running method {{method}}: {{e}}")
    #              import traceback; traceback.print_exc()

    print(f"--- Refinement Script Setup Complete (Execution Skipped) ---")

    # Example command-line usage:
    # python scripts/run_refinement.py --env Hopper-v3 --methods rice,ppo_finetune,statemask_r,rice_nomask
