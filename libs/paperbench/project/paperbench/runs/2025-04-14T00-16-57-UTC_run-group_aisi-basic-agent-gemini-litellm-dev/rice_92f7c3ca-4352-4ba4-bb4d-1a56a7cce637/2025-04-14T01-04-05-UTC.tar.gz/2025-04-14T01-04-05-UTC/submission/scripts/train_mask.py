import os
import sys
import argparse
import json

# Ensure src is in path if running script directly
try:
    script_dir = os.path.dirname(__file__)
except NameError:
    script_dir = '/home/submission/scripts' # Fallback
sys.path.append(os.path.abspath(os.path.join(script_dir, '..', 'src')))

try:
    from state_mask import train_mask_network
except ImportError as e:
    print(f"Error importing train_mask_network from state_mask: {e}")
    print("Please ensure state_mask.py is in the src directory.")
    # Define dummy function if import fails, to allow script creation
    def train_mask_network(*args, **kwargs):
        print("[Dummy] train_mask_network called (Import failed).", flush=True)
        print(f"[Dummy] Args: {args}", flush=True)
        print(f"[Dummy] Kwargs: {kwargs}", flush=True)
        save_path = kwargs.get('save_path', '/tmp/dummy_mask.zip')
        print(f"[Dummy] Would save mask network to: {save_path}", flush=True)
        return None # Indicate failure or dummy success
        return None # Indicate failure or dummy success

# Defaults based on paper Appendix C.3 Table 3 and text
DEFAULT_ALPHAS = {
    "Hopper-v3": 0.001, # From paper text example/correction, table has 0.0001
    "Walker2d-v3": 0.0001,
    "Reacher-v2": 0.0001,
    "HalfCheetah-v3": 0.0001,
    "SelfishMining": 0.0001, # Assuming similar small alpha for others
    "CageChallenge2": 0.0001,
    "AutoDriving": 0.0001,
    "Default": 0.001 # Fallback
}

# Training timesteps based on Table 4 (approximated)
DEFAULT_MASK_TIMESTEPS = {
    "Hopper-v3": 300_000,
    "Walker2d-v3": 300_000, # Table 4 has different num samples, maybe steps vary?
    "Reacher-v2": 300_000,
    "HalfCheetah-v3": 300_000,
    "SelfishMining": 1_500_000,
    "CageChallenge2": 10_000_000,
    "AutoDriving": 2_500_000,
    "Default": 300_000 # Fallback
}


if __name__ == "__main__":
    # Define directories relative to script location
    try:
        script_dir = os.path.dirname(__file__)
    except NameError:
        script_dir = '/home/submission/scripts' # Fallback
    default_pretrained_dir = os.path.abspath(os.path.join(script_dir, '..', 'models', 'pretrained'))
    default_mask_save_dir = os.path.abspath(os.path.join(script_dir, '..', 'models', 'mask_nets'))

    parser = argparse.ArgumentParser(description="Train StateMask Network (Algorithm 1)")
    parser.add_argument("--env", help="Environment ID", type=str, required=True)
    # Allow pretrained path to be optional if user wants to only print command
    parser.add_argument("--pretrained-path", help="Path to the pre-trained agent (.zip)", type=str, default=None)
    parser.add_argument("--pretrained-algo", help="Algorithm of the pre-trained agent (PPO or SAC)", type=str, default="PPO")
    parser.add_argument("--alpha", help="Alpha hyperparameter for mask reward bonus", type=float, default=None)
    parser.add_argument("--timesteps", help="Total training timesteps for mask network", type=int, default=None)
    parser.add_argument("--save-dir", help="Directory to save the trained mask network", type=str, default=default_mask_save_dir)
    parser.add_argument("--seed", help="Random seed", type=int, default=42)
    parser.add_argument("--n-envs", help="Number of parallel environments", type=int, default=4)
    parser.add_argument("--ppo-kwargs", help="JSON string of PPO kwargs for mask training", type=str, default='{}')

    args, unknown = parser.parse_known_args()

    # Infer default pretrained path if not provided
    pretrained_path = args.pretrained_path
    if not pretrained_path:
        pretrained_filename = f"{args.env}_{args.pretrained_algo.lower()}_pretrained.zip"
        pretrained_path = os.path.join(default_pretrained_dir, pretrained_filename)
        print(f"Note: --pretrained-path not provided, assuming default: {pretrained_path}")
        # Check if the assumed default exists, warn if not
        if not os.path.exists(pretrained_path):
            print(f"Warning: Default pretrained path does not exist. Training call will likely fail.")
            print(f"Please train the pretrained model first or provide the correct path.")

    # Use default alpha/timesteps if not provided
    alpha = args.alpha if args.alpha is not None else DEFAULT_ALPHAS.get(args.env, DEFAULT_ALPHAS["Default"])
    timesteps = args.timesteps if args.timesteps is not None else DEFAULT_MASK_TIMESTEPS.get(args.env, DEFAULT_MASK_TIMESTEPS["Default"])

    # Construct save path
    os.makedirs(args.save_dir, exist_ok=True)
    mask_save_path = os.path.join(args.save_dir, f"{args.env}_mask_net_alpha{alpha}_seed{args.seed}.zip")

    # Parse PPO kwargs
    try:
        ppo_kwargs_dict = json.loads(args.ppo_kwargs)
    except json.JSONDecodeError:
        print(f"Warning: Could not parse ppo-kwargs JSON string: {args.ppo_kwargs}. Using defaults.")
        ppo_kwargs_dict = {}

    print(f"--- Training Mask Network --- ", flush=True)
    print(f" Env: {args.env}", flush=True)
    print(f" Pretrained Agent: {pretrained_path} ({args.pretrained_algo})", flush=True)
    print(f" Alpha: {alpha}", flush=True)
    print(f" Timesteps: {timesteps}", flush=True)
    print(f" Save Path: {mask_save_path}", flush=True)
    print(f" Seed: {args.seed}, N_Envs: {args.n_envs}", flush=True)
    print(f" PPO Kwargs: {ppo_kwargs_dict}", flush=True)
    print(f"--- Starting setup... (Execution Skipped) ---", flush=True)

    # --- Call training function (Commented out) ---
    # if not pretrained_path or not os.path.exists(pretrained_path):
    #     print("Error: Pretrained agent path does not exist or not specified. Cannot start mask training.")
    # else:
    #     try:
    #         train_mask_network(
    #             env_id=args.env,
    #             target_policy_path=pretrained_path,
    #             target_policy_algo=args.pretrained_algo.upper(),
    #             alpha=alpha,
    #             total_timesteps=timesteps,
    #             save_path=mask_save_path,
    #             n_envs=args.n_envs,
    #             seed=args.seed,
    #             ppo_kwargs=ppo_kwargs_dict
    #             # policy_kwargs can be added here if needed
    #         )
    #         print(f"--- Mask Training Setup Complete (Execution Skipped) ---")
    #         print(f"--- Trained mask network would be saved to: {mask_save_path} ---")
    #     except ImportError:
    #          print("Skipping mask training call due to previous import error.")
    #     except Exception as e:
    #         print(f"Error during mask training setup: {e}")

    # Example command-line usage:
    # Assumes a pretrained PPO agent exists at ../models/pretrained/Hopper-v3_ppo_pretrained.zip
    # python scripts/train_mask.py --env Hopper-v3     #   --pretrained-path ../models/pretrained/Hopper-v3_ppo_pretrained.zip     #   --pretrained-algo PPO

