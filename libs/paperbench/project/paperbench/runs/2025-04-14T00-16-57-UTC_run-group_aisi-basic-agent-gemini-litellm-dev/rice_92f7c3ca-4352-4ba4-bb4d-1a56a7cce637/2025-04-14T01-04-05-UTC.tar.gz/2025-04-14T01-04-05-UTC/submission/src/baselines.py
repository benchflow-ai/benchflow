import os
import sys
import numpy as np
import gymnasium as gym
from stable_baselines3 import PPO, SAC
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.vec_env import DummyVecEnv, VecEnvWrapper
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.policies import BasePolicy

# Ensure src is in path if running script directly
try:
    script_dir = os.path.dirname(__file__)
except NameError:
    script_dir = '/home/submission/src' # Fallback
sys.path.append(os.path.abspath(os.path.join(script_dir))) # Add src dir

try:
    # Need these for StateMask-R and loading policies
    from rice import CriticalStateResetWrapper, RICECallback
    from state_mask import MaskNetworkPolicy
    from fidelity import load_policy
except ImportError as e:
    print(f"Warning: Could not import from rice/state_mask/fidelity: {e}. Using dummies.")
    # Dummy classes needed for structure
    class CriticalStateResetWrapper(VecEnvWrapper):
        def __init__(self, venv, p_critical): super().__init__(venv)
        def set_critical_states(self, states): pass
    class RICECallback(BaseCallback):
        def __init__(self, *args, **kwargs): super().__init__(0)
        def _on_step(self): return True
        def _on_training_start(self): pass # Need dummy method
        def _on_rollout_start(self): pass # Need dummy method
        def _on_rollout_end(self): pass # Need dummy method
    class MaskNetworkPolicy(BasePolicy):
        obs_space = gym.spaces.Box(-1, 1, (1,)) ; act_space = gym.spaces.Box(-1, 1, (1,))
        def __init__(self, *args, **kwargs): 
             try: super().__init__(*args, **kwargs)
             except: super().__init__(observation_space=self.obs_space, action_space=self.act_space)
        def predict_mask_prob(self, states): return np.zeros(len(states))
        def set_training_mode(self, mode): pass
        def to(self, device): return self
    # Dummy load_policy that returns None to indicate failure or dummy obj
    def load_policy(policy_path, algo_name, custom_policy_class=None, *args, **kwargs):
        print(f"[Dummy] load_policy called for {policy_path} ({algo_name}).", flush=True)
        if not os.path.exists(policy_path):
             print(f"[Dummy] Policy file not found: {policy_path}")
             return None
        # Return a dummy policy object
        class DummyPolicy(BasePolicy):
            obs_space = gym.spaces.Box(-1, 1, (11,)) # Hopper obs space
            act_space = gym.spaces.Box(-1, 1, (3,)) # Hopper action space
            def __init__(self):
                try: super().__init__(observation_space=self.obs_space, action_space=self.act_space)
                except TypeError: super().__init__()
            def predict(self, obs, state=None, episode_start=None, deterministic=False): return self.action_space.sample() * 0, state
            def set_training_mode(self, mode): pass
            def parameters(self): yield torch.nn.Parameter(torch.tensor(1.0))
            def to(self, device): return self
            def predict_mask_prob(self, states): return np.random.rand(len(states))
        if custom_policy_class and issubclass(custom_policy_class, MaskNetworkPolicy):
             return MaskNetworkPolicy(observation_space=DummyPolicy.obs_space, action_space=gym.spaces.Discrete(2), lr_schedule=lambda _:0)
        else:
             return DummyPolicy()

# --- Baseline 1: PPO Fine-tuning ---

def train_ppo_finetune(
    env_id: str,
    pretrained_policy_path: str,
    pretrained_algo: str, # PPO or SAC
    save_path: str,
    total_timesteps: int,
    n_envs: int = 4,
    seed: int = 42,
    learning_rate: float = 1e-5, # Often use smaller LR for fine-tuning
    ppo_kwargs: dict = None,
    log_folder: str = "/tmp/ppo_finetune_logs/"
):
    ''' Fine-tunes a pretrained agent using PPO. '''
    print(f"--- Baseline: PPO Fine-tuning ---", flush=True)
    print(f" Env: {env_id}, Pretrained: {pretrained_policy_path} ({pretrained_algo})", flush=True)
    print(f" Timesteps: {total_timesteps}, LR: {learning_rate}, Seed: {seed}", flush=True)
    print(f" Save Path: {save_path}", flush=True)

    # --- Load Pretrained Model --- #
    print("Loading pretrained model...", flush=True)
    model_loaded = False
    original_model = None
    try:
        algo_map = {'PPO': PPO, 'SAC': SAC}
        AlgoClass = algo_map.get(pretrained_algo.upper())
        if not AlgoClass: raise ValueError(f"Unsupported pretrained algo: {pretrained_algo}")
        if not os.path.exists(pretrained_policy_path):
             print(f"Error: Pretrained model file not found: {pretrained_policy_path}")
             return
        original_model = AlgoClass.load(pretrained_policy_path, device='auto')
        print("Pretrained model loaded.", flush=True)
        model_loaded = True
    except Exception as e:
        print(f"Error loading pretrained model: {e}")
        if 'DummyModel' in str(e):
             print("(Continuing with dummy structure due to load failure)")
        else:
             return # Real error, stop

    # --- Setup Environment --- #
    print(f"Creating environment (n={n_envs})...", flush=True)
    try:
        vec_env = make_vec_env(env_id, n_envs=n_envs, seed=seed)
        # TODO: Handle VecNormalize loading if necessary
    except Exception as e:
        print(f"Error creating environment: {e}")
        return

    # --- Setup PPO for Fine-tuning --- #
    finetune_model = None
    if model_loaded and isinstance(original_model, PPO):
        print("Pretrained is PPO. Adjusting parameters.", flush=True)
        original_model.set_env(vec_env)
        original_model.learning_rate = learning_rate
        original_model.tensorboard_log = log_folder
        if ppo_kwargs: # Apply overrides
             for key, value in ppo_kwargs.items():
                  if hasattr(original_model, key): setattr(original_model, key, value)
        finetune_model = original_model
    elif model_loaded and isinstance(original_model, SAC):
        print("Pretrained is SAC. Creating new PPO model using SAC policy.", flush=True)
        ppo_params = {
            "verbose": 1, "seed": seed, "n_steps": 2048, "batch_size": 64,
            "n_epochs": 10, "gamma": 0.99, "gae_lambda": 0.95, "clip_range": 0.2,
            "ent_coef": 0.0, "vf_coef": 0.5, "max_grad_norm": 0.5,
            "learning_rate": learning_rate, "device": original_model.device,
            "tensorboard_log": log_folder
        }
        if ppo_kwargs: ppo_params.update(ppo_kwargs)
        try:
            finetune_model = PPO(type(original_model.policy), vec_env, **ppo_params)
            finetune_model.policy.load_state_dict(original_model.policy.state_dict(), strict=False)
            print("Initialized PPO with SAC weights (strict=False).", flush=True)
        except Exception as e:
            print(f"Error initializing PPO with SAC policy: {e}.", flush=True)
    # Handle case where dummy model was used
    elif original_model is None and 'DummyModel' in str(e):
         print("Pretrained model failed to load (dummy used). Creating dummy PPO.", flush=True)
         # Use defaults that work with dummy policy structure
         dummy_ppo_params = {
            "verbose": 1, "seed": seed, "n_steps": 64, "batch_size": 32,
            "n_epochs": 1, "learning_rate": learning_rate,
            "tensorboard_log": log_folder
         }
         finetune_model = PPO("MlpPolicy", vec_env, **dummy_ppo_params) # Assume MlpPolicy
    else:
        print(f"Error: Unexpected model type or load failure.", flush=True)

    if finetune_model is None:
        print("Failed to setup fine-tuning model. Aborting.", flush=True)
        vec_env.close()
        return

    # --- Train (Commented Out) --- #
    print(f"Starting PPO fine-tuning setup... (Execution Skipped)", flush=True)
    # try:
    #     finetune_model.learn(...)
    #     finetune_model.save(save_path)
    # except Exception as e: print(f"Error: {e}")
    # finally: vec_env.close()
    print(f"--- PPO Fine-tuning Setup Complete (Execution Skipped) ---")
    print(f"--- Final model would be saved to: {save_path} ---")
    vec_env.close()


# --- Baseline 2: StateMask-R ---

def train_statemask_r(
    env_id: str,
    pretrained_policy_path: str,
    pretrained_algo: str,
    mask_network_path: str,
    save_path: str,
    total_timesteps: int,
    n_envs: int = 4,
    seed: int = 42,
    learning_rate: float = 1e-5,
    ppo_kwargs: dict = None,
    critical_state_update_freq: int = 10000,
    max_traj_len: int = 1000,
    log_folder: str = "/tmp/statemask_r_logs/"
):
    ''' Fine-tunes using PPO, resetting ONLY to critical states (p=1, lambda=0). '''
    print(f"--- Baseline: StateMask-R ---", flush=True)
    print(f" Env: {env_id}, Pretrained: {pretrained_policy_path} ({pretrained_algo})", flush=True)
    print(f" MaskNet: {mask_network_path}", flush=True)
    print(f" Timesteps: {total_timesteps}, LR: {learning_rate}, Seed: {seed}", flush=True)
    print(f" Save Path: {save_path}", flush=True)

    # --- Load Policies --- #
    print("Loading policies...", flush=True)
    target_policy_obj = load_policy(pretrained_policy_path, pretrained_algo.upper())
    mask_policy_obj = load_policy(mask_network_path, 'PPO', custom_policy_class=MaskNetworkPolicy)

    if not target_policy_obj:
        print("Error: Failed to load target policy. Aborting StateMask-R.")
        return
    if not mask_policy_obj:
        print("Error: Failed to load mask network policy. Aborting StateMask-R.")
        return

    # --- Setup Environment --- #
    print(f"Creating environment (n={n_envs}, DummyVecEnv required)...", flush=True)
    try:
        vec_env = make_vec_env(env_id, n_envs=n_envs, seed=seed, vec_env_cls=DummyVecEnv)
    except Exception as e:
        print(f"Error creating environment: {e}")
        return

    # --- Wrap Environment --- #
    print("Wrapping environment (p_critical=1.0)...", flush=True)
    try:
         reset_wrapper = CriticalStateResetWrapper(vec_env, p_critical=1.0)
         wrapped_env = reset_wrapper
    except Exception as e:
         print(f"Error wrapping environment: {e}")
         vec_env.close()
         return

    # --- Setup PPO Model --- #
    print("Initializing PPO model for refinement...", flush=True)
    model = None
    try:
        algo_map = {'PPO': PPO, 'SAC': SAC}
        PretrainedClass = algo_map.get(pretrained_algo.upper())
        if not PretrainedClass: raise ValueError(f"Unsupported pretrained algo: {pretrained_algo}")

        # Load original model structure/params if possible
        original_model_policy_state_dict = None
        original_model_device = 'auto'
        if os.path.exists(pretrained_policy_path):
             try:
                 # Load just to get state dict and device
                 temp_model = PretrainedClass.load(pretrained_policy_path, device='cpu')
                 original_model_policy_state_dict = temp_model.policy.state_dict()
                 original_model_device = temp_model.device
                 del temp_model # Free memory
             except Exception as load_e:
                 print(f"Warning: Failed to load actual pretrained model {pretrained_policy_path}: {load_e}")

        # Default PPO params for refinement
        ppo_params = {
            "verbose": 1, "seed": seed, "n_steps": 2048, "batch_size": 64,
            "n_epochs": 10, "gamma": 0.99, "gae_lambda": 0.95, "clip_range": 0.2,
            "ent_coef": 0.0, "vf_coef": 0.5, "max_grad_norm": 0.5,
            "learning_rate": learning_rate,
            "device": original_model_device,
            "tensorboard_log": log_folder
        }
        if ppo_kwargs: ppo_params.update(ppo_kwargs)

        # Create the PPO model using the correct policy type
        policy_type = type(target_policy_obj) if target_policy_obj else "MlpPolicy"
        model = PPO(policy_type, wrapped_env, **ppo_params)

        # Load weights if available
        if original_model_policy_state_dict:
            model.policy.load_state_dict(original_model_policy_state_dict, strict=False)
            print("Initialized PPO with pretrained weights (strict=False).", flush=True)
        else:
            print("Warning: Could not load weights from pretrained model. Using fresh PPO.", flush=True)

    except Exception as e:
        print(f"Error initializing refinement model: {e}")
        wrapped_env.close()
        return

    # --- Setup Callback --- #
    print("Setting up callback for critical state updates...", flush=True)
    try:
        state_update_callback = RICECallback(
            rnd_nets=None, obs_normalizer=None, rnd_optimizer=None,
            rollout_buffer=model.rollout_buffer,
            target_policy=target_policy_obj,
            mask_policy=mask_policy_obj,
            reset_wrapper=reset_wrapper,
            critical_state_update_freq=critical_state_update_freq,
            rnd_train_freq=float('inf'), # Disable RND training
            max_traj_len=max_traj_len,
            verbose=1
        )
    except Exception as e:
         print(f"Error creating callback: {e}. Cannot run training.")
         wrapped_env.close()
         return

    # --- Train (Commented Out) --- #
    print(f"Starting StateMask-R training setup... (Execution Skipped)", flush=True)
    # try:
    #     model.learn(...)
    #     model.save(save_path)
    # except Exception as e: print(f"Error: {e}")
    # finally: wrapped_env.close()
    print(f"--- StateMask-R Setup Complete (Execution Skipped) ---")
    print(f"--- Final model would be saved to: {save_path} ---")
    wrapped_env.close()


if __name__ == '__main__':
    # Example usage (requires dummy files to exist)
    DUMMY_AGENT_PATH = "/tmp/dummy_ppo_hopper.zip"
    DUMMY_MASK_PATH = "/home/submission/results/hopper_mask_net.zip"
    ENV_ID = "Hopper-v3"

    print("--- Baseline Examples (Setup Only) ---", flush=True)

    print("Example: PPO Fine-tuning Setup", flush=True) # Removed 

    # Check if agent exists before calling
    if not os.path.exists(DUMMY_AGENT_PATH):
         print(f"Skipping PPO Fine-tuning example: Missing {DUMMY_AGENT_PATH}")
    else:
        train_ppo_finetune(
            env_id=ENV_ID,
            pretrained_policy_path=DUMMY_AGENT_PATH,
            pretrained_algo="PPO",
            save_path="/home/submission/results/hopper_ppo_finetuned.zip",
            total_timesteps=50000, # Short run
            learning_rate=1e-5
        )

    print("Example: StateMask-R Setup", flush=True) # Removed 

    # Check if files exist before calling
    agent_exists = os.path.exists(DUMMY_AGENT_PATH)
    mask_exists = os.path.exists(DUMMY_MASK_PATH)
    if not agent_exists: print(f" - Agent Missing: {DUMMY_AGENT_PATH}")
    if not mask_exists: print(f" - Mask Missing: {DUMMY_MASK_PATH}")

    if agent_exists and mask_exists:
        train_statemask_r(
            env_id=ENV_ID,
            pretrained_policy_path=DUMMY_AGENT_PATH,
            pretrained_algo="PPO",
            mask_network_path=DUMMY_MASK_PATH,
            save_path="/home/submission/results/hopper_statemask_r.zip",
            total_timesteps=50000, # Short run
            learning_rate=1e-5
        )
    else:
        print(f"Skipping StateMask-R example: Prerequisite files missing.")
