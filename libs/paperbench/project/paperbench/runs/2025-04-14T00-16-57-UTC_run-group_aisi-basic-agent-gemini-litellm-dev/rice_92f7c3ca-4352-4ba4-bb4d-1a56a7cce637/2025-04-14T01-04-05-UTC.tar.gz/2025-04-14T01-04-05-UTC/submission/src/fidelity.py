import gymnasium as gym
import numpy as np
import torch
import time
import os # Added os import
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.policies import BasePolicy # For dummy policy

# Assuming MaskNetworkPolicy is available for loading mask models
try:
    from state_mask import MaskNetworkPolicy
    from stable_baselines3 import PPO, SAC # To load target/mask models
except ImportError:
    print("WARNING: Could not import state_mask/SB3. Using dummy classes for fidelity.py.")
    class MaskNetworkPolicy(BasePolicy): # Dummy for structure
         # Need dummy observation/action space for BasePolicy constructor
         obs_space = gym.spaces.Box(-1, 1, (1,))
         act_space = gym.spaces.Box(-1, 1, (1,))
         def __init__(self, *args, **kwargs):
             # Try initializing BasePolicy with dummy spaces if constructor needs them
             try:
                 super().__init__(observation_space=self.obs_space, action_space=self.act_space)
             except TypeError: # Handle potential signature changes
                 super().__init__()

         def predict_mask_prob(self, states): return np.random.rand(len(states)) # Random prob
         def set_training_mode(self, mode): pass
         def to(self, device): return self # Dummy device move
         def parameters(self): yield torch.nn.Parameter(torch.tensor(1.0)) # Dummy parameters

    class DummyModel:
        policy = None
        @staticmethod
        def load(policy_path, *args, **kwargs):
            print(f"[Dummy Load] Loading model from {policy_path}")
            model = DummyModel()
            # Create a dummy policy object satisfying basic needs
            class DummyPolicy(BasePolicy):
                obs_space = gym.spaces.Box(-1, 1, (11,)) # Hopper obs space
                act_space = gym.spaces.Box(-1, 1, (3,)) # Hopper action space
                def __init__(self):
                    try:
                         super().__init__(observation_space=self.obs_space, action_space=self.act_space)
                    except TypeError:
                         super().__init__()
                def predict(self, obs, state=None, episode_start=None, deterministic=False):
                    # Return dummy action matching Hopper action space
                    action = self.action_space.sample() * 0 # Zero action
                    return action, state
                def set_training_mode(self, mode): pass
                def parameters(self): yield torch.nn.Parameter(torch.tensor(1.0))
                def to(self, device): return self

            # Instantiate the correct policy class (even if dummy)
            policy_class_to_use = kwargs.get('custom_objects', {}).get('policy_class', DummyPolicy)
            # Create dummy observation space if not provided by class
            obs_space = getattr(policy_class_to_use, 'obs_space', gym.spaces.Box(-1, 1, (1,))) 
            act_space = getattr(policy_class_to_use, 'act_space', gym.spaces.Box(-1, 1, (1,))) 
            # A dummy lr_schedule is often needed by ActorCriticPolicy constructor
            lr_schedule = lambda _: 1e-4 
            try:
                # Attempt instantiation with common SB3 policy args
                model.policy = policy_class_to_use(observation_space=obs_space, action_space=act_space, lr_schedule=lr_schedule)
            except Exception as policy_init_e:
                print(f"[Dummy Load] Warning: Failed to init policy {policy_class_to_use} normally: {policy_init_e}. Trying basic init.")
                try: 
                    model.policy = policy_class_to_use() # Fallback basic init
                except Exception as basic_init_e:
                    print(f"[Dummy Load] Error: Failed basic policy init: {basic_init_e}")
                    raise # Re-raise if even basic init fails

            # Add predict_mask_prob if loading mask policy
            if policy_class_to_use == MaskNetworkPolicy:
                 model.policy.predict_mask_prob = lambda states: np.random.rand(len(states))
            return model

    PPO = DummyModel
    SAC = DummyModel


# Helper function to get MuJoCo state if possible
def get_env_state(env):
    # Tries to get the MuJoCo state (qpos, qvel).
    if hasattr(env, 'get_state'):
        try:
            qpos, qvel = env.get_state()
            return qpos.copy(), qvel.copy()
        except Exception: return None
    return None

# Helper function to set MuJoCo state if possible
def set_env_state(env, state):
    # Tries to set the MuJoCo state (qpos, qvel).
    if hasattr(env, 'set_state') and state is not None:
        try:
            qpos, qvel = state
            env.set_state(qpos, qvel)
            return True
        except Exception: return False
    return False

def get_importance_scores(policy, trajectory_states: np.ndarray) -> np.ndarray:
    # Get step-level importance scores using explanation policy.
    # Score = P(a^m = 0 | s_t) = 1 - P(a^m = 1 | s_t).
    if not hasattr(policy, 'predict_mask_prob'):
        raise ValueError("Policy must have 'predict_mask_prob' method.")

    with torch.no_grad():
        policy.set_training_mode(False)
        # Ensure policy is on CPU if states are numpy
        policy.to('cpu')
        prob_blind = policy.predict_mask_prob(trajectory_states)
        importance_scores = 1.0 - prob_blind
    return importance_scores

def get_random_importance_scores(trajectory_length: int) -> np.ndarray:
    # Returns random importance scores.
    return np.random.rand(trajectory_length)


def find_critical_segment(importance_scores: np.ndarray, segment_length: int) -> tuple[int, float]:
    # Find the segment with the highest average importance score.
    trajectory_length = len(importance_scores)
    segment_length = int(segment_length) # Ensure integer
    if segment_length <= 0 or segment_length > trajectory_length:
        return -1, -float('inf')

    max_avg_score = -float('inf')
    best_start_index = -1
    if trajectory_length == segment_length:
         # Handle edge case where segment is the whole trajectory
         return 0, np.mean(importance_scores)

    # Use rolling window mean for efficiency if pandas is available
    try:
        import pandas as pd
        # Ensure input is float64 for potentially better precision with rolling
        scores_series = pd.Series(importance_scores, dtype=np.float64)
        rolling_mean = scores_series.rolling(window=segment_length).mean().to_numpy()
        # rolling_mean has NaNs at the start, corresponding indices are i = window-1, window, ...
        valid_means = rolling_mean[segment_length-1:]
        if len(valid_means) == 0:
             return -1, -float('inf')
        best_valid_idx = np.nanargmax(valid_means)
        max_avg_score = valid_means[best_valid_idx]
        # The index in the original array is (segment_length - 1) + best_valid_idx - (segment_length - 1) = best_valid_idx
        best_start_index = best_valid_idx
    except ImportError:
        # Manual sliding window if pandas is not available
        if segment_length == 0: return -1, -float('inf') # Avoid division by zero
        current_window_sum = np.sum(importance_scores[:segment_length])
        max_avg_score = current_window_sum / segment_length
        best_start_index = 0
        for i in range(1, trajectory_length - segment_length + 1):
            current_window_sum = current_window_sum - importance_scores[i-1] + importance_scores[i + segment_length - 1]
            current_avg_score = current_window_sum / segment_length
            if current_avg_score > max_avg_score:
                max_avg_score = current_avg_score
                best_start_index = i

    return best_start_index, max_avg_score


def run_perturbed_trajectory(env, policy, start_state, segment_start_index: int, segment_length: int, max_steps: int, random_seed=None) -> float:
    # Runs a trajectory: reset to start_state, random actions for segment_length, then policy.
    total_reward_perturbed = 0.0
    try:
        obs, _ = env.reset() # Reset first
        if not set_env_state(env, start_state):
            print("Warning: Failed set_env_state in perturbed run.")
            return -float('inf')

        # Get observation corresponding to the set state
        if hasattr(env, '_get_obs'): obs = env._get_obs()
        # Handle environments that might not have _get_obs (like older gym)
        # elif hasattr(env, 'state') and hasattr(env, 'observation'): obs = env.observation(env.state)
        else: # Last resort: step with dummy action? Risky.
            try:
                obs, _, _, _, _ = env.step(env.action_space.sample() * 0)
                print("Warning: Used dummy step to get obs after set_state.")
            except Exception:
                 print("Error: Cannot get obs after set_state.")
                 return -float('inf')

        # Random Action Segment
        if random_seed is not None: env.action_space.seed(random_seed)
        current_step = segment_start_index # Keep track based on original trajectory indices
        segment_length = int(segment_length) # Ensure integer
        for t in range(segment_length):
            random_action = env.action_space.sample()
            obs, reward, terminated, truncated, info = env.step(random_action)
            total_reward_perturbed += reward
            current_step += 1
            if terminated or truncated or current_step >= max_steps:
                return total_reward_perturbed

        # Policy Execution Segment
        done = False
        policy.set_training_mode(False)
        policy.to('cpu') # Ensure policy on CPU for numpy obs
        while not done and current_step < max_steps:
            with torch.no_grad():
                action, _ = policy.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, info = env.step(action)
            total_reward_perturbed += reward
            done = terminated or truncated
            current_step += 1
        return total_reward_perturbed

    except Exception as e:
        print(f"Error during perturbed run: {e}")
        import traceback; traceback.print_exc()
        return -float('inf')


def calculate_fidelity_score(
    env_id: str,
    target_policy,
    explanation_policy, # Can be None for Random
    k_fraction: float,
    d_max: float,
    num_trajectories: int = 100,
    max_traj_len: int = 1000,
    seed: int = 42
) -> tuple[float, float]:
    # Calculates the fidelity score.
    try:
        env = gym.make(env_id)
    except Exception as e:
        print(f"Error creating env {env_id}: {e}")
        return float('nan'), float('nan')

    env.reset(seed=seed)
    if hasattr(env.action_space, 'seed'): env.action_space.seed(seed)

    target_policy.set_training_mode(False)
    if explanation_policy: explanation_policy.set_training_mode(False)

    fidelity_scores = []
    can_get_set_state = hasattr(env, 'get_state') and hasattr(env, 'set_state')
    if not can_get_set_state:
         print(f"Warning: Env {env_id} lacks get/set_state for fidelity calculation.")

    for i in range(num_trajectories):
        # Print progress periodically
        if i % max(1, num_trajectories // 10) == 0:
             print(f" Fidelity Trajectory {i+1}/{num_trajectories}...", flush=True)
        obs, _ = env.reset()
        done = False
        original_reward = 0.0
        trajectory_states = []
        # Store MuJoCo states only if env supports it and it hasn't failed yet
        trajectory_mujoco_states = [] if can_get_set_state else None
        current_step = 0
        traj_can_get_set_state = can_get_set_state # Track per-trajectory

        # 1. Generate original trajectory R
        try:
            with torch.no_grad():
                 target_policy.to('cpu') # Run on CPU
                 while not done and current_step < max_traj_len:
                      trajectory_states.append(obs.copy())
                      if traj_can_get_set_state:
                           mujoco_state = get_env_state(env)
                           if mujoco_state:
                                trajectory_mujoco_states.append(mujoco_state)
                           else:
                                if current_step == 0: print(f" Traj {i+1}: Failed get_env_state.")
                                traj_can_get_set_state = False # Disable if fails
                                trajectory_mujoco_states = None

                      action, _ = target_policy.predict(obs, deterministic=False)
                      obs, reward, terminated, truncated, info = env.step(action)
                      original_reward += reward
                      done = terminated or truncated
                      current_step += 1
        except Exception as e:
             print(f" Traj {i+1}: Error generating trajectory: {e}")
             continue # Skip to next trajectory

        trajectory_length = len(trajectory_states)
        if trajectory_length == 0: continue

        # 2. Get importance scores
        try:
             if explanation_policy:
                 # Ensure explanation policy is on CPU
                 explanation_policy.to('cpu')
                 importance_scores = get_importance_scores(explanation_policy, np.array(trajectory_states))
             else: # Random explanation
                 importance_scores = get_random_importance_scores(trajectory_length)
        except Exception as e:
             print(f" Traj {i+1}: Error getting importance scores: {e}")
             continue

        # 3. Find critical segment
        segment_length = max(1, int(trajectory_length * k_fraction))
        critical_start_index, avg_score = find_critical_segment(importance_scores, segment_length)
        if critical_start_index == -1:
             if i==0: print(f" Traj {i+1}: Could not find valid segment.")
             continue

        # 4. Run perturbed trajectory R'
        perturbed_reward = -float('inf') # Default to failure
        if not traj_can_get_set_state or trajectory_mujoco_states is None or critical_start_index >= len(trajectory_mujoco_states):
            if i==0: print("  Skipping perturbed run: Cannot get/set state reliably.")
        else:
             state_at_critical_start = trajectory_mujoco_states[critical_start_index]
             perturbed_reward = run_perturbed_trajectory(env, target_policy, state_at_critical_start,
                                                      critical_start_index, segment_length,
                                                      max_steps=max_traj_len, random_seed=seed + i + 1)

        # 5. Calculate score
        if perturbed_reward == -float('inf') or d_max <= 0:
             if i==0: print(f"  Could not calculate score (pert_R={perturbed_reward}, d_max={d_max})")
             continue

        reward_change_d = abs(perturbed_reward - original_reward)
        term1_arg = max(reward_change_d, 1e-9) / d_max
        term2_arg = max(segment_length, 1e-9) / max(trajectory_length, 1e-9)
        score = np.log(max(term1_arg, 1e-9)) - np.log(max(term2_arg, 1e-9))
        fidelity_scores.append(score)
        # if i % max(1, num_trajectories // 5) == 0:
        #      print(f"  Traj {i+1}: OrigR={original_reward:.1f}, PertR={perturbed_reward:.1f}, d={reward_change_d:.1f}, score={score:.3f}")

    env.close()

    if not fidelity_scores:
         print("No valid fidelity scores calculated.")
         return float('nan'), float('nan')

    avg_fidelity = np.mean(fidelity_scores)
    std_fidelity = np.std(fidelity_scores)
    # Print final result with a newline before it for separation
    print(f"Avg Fidelity ({{len(fidelity_scores)}} valid traj): {{avg_fidelity:.4f}} (+/- {{std_fidelity:.4f}})")
    return avg_fidelity, std_fidelity


# --- Helper to load policies ---
def load_policy(policy_path: str, algo_name: str, custom_policy_class=None):
    # Loads a policy object from a saved model file.
    if not os.path.exists(policy_path):
         print(f"Error: Policy file not found: {policy_path}")
         return None
    try:
        algo_map = {'PPO': PPO, 'SAC': SAC}
        AlgoClass = algo_map.get(algo_name)
        if not AlgoClass: raise ValueError(f"Unsupported algo: {algo_name}")

        custom_objects = None
        if custom_policy_class:
             # The key must match how SB3 handles policy class loading
             custom_objects = {"policy_class": custom_policy_class}

        model = AlgoClass.load(policy_path, device='cpu', custom_objects=custom_objects)
        return model.policy
    except Exception as e:
        print(f"Error loading policy {policy_path} ({algo_name}): {e}")
        import traceback; traceback.print_exc()
        return None


if __name__ == '__main__':
    print("--- Fidelity Score Example --- ")
    # Assume dummy agent and mask net exist from state_mask.py example run
    # Since those likely failed, this example will probably skip execution.
    DUMMY_AGENT_PATH = "/tmp/dummy_ppo_hopper.zip"
    DUMMY_MASK_PATH = "/home/submission/results/hopper_mask_net.zip"
    ENV_ID = "Hopper-v3"
    # Use a placeholder D_MAX, needs proper estimation per environment
    D_MAX_HOPPER = 3600.0

    print(f"Checking prerequisites...")
    agent_exists = os.path.exists(DUMMY_AGENT_PATH)
    mask_exists = os.path.exists(DUMMY_MASK_PATH)
    print(f" Agent: {DUMMY_AGENT_PATH} (Exists: {agent_exists})")
    print(f" Mask: {DUMMY_MASK_PATH} (Exists: {mask_exists})")

    if not agent_exists or not mask_exists:
        print("Skipping fidelity calculation example as prerequisite files are missing.") # Removed 

    else:
        print(f"Loading policies for {ENV_ID}...") # Removed 

        target_policy = load_policy(DUMMY_AGENT_PATH, 'PPO')
        mask_policy = load_policy(DUMMY_MASK_PATH, 'PPO', custom_policy_class=MaskNetworkPolicy)

        if target_policy and mask_policy:
            print("Calculating Fidelity for Mask Network...") # Removed 

            k = 0.1 # K=10%
            num_traj = 5 # Small number for example

            avg_score_mask, std_score_mask = calculate_fidelity_score(
                env_id=ENV_ID,
                target_policy=target_policy,
                explanation_policy=mask_policy,
                k_fraction=k,
                d_max=D_MAX_HOPPER,
                num_trajectories=num_traj,
                seed=42,
                max_traj_len=1000 # Default for Hopper
            )
            # Final print happens inside calculate_fidelity_score

            print("Calculating Fidelity for Random Explanation...") # Removed 

            avg_score_rand, std_score_rand = calculate_fidelity_score(
                env_id=ENV_ID,
                target_policy=target_policy,
                explanation_policy=None, # Use Random
                k_fraction=k,
                d_max=D_MAX_HOPPER,
                num_trajectories=num_traj,
                seed=123 # Use different seed
            )
            # Final print happens inside calculate_fidelity_score
        else:
            print("Could not load policies, skipping fidelity calculation.") # Removed
