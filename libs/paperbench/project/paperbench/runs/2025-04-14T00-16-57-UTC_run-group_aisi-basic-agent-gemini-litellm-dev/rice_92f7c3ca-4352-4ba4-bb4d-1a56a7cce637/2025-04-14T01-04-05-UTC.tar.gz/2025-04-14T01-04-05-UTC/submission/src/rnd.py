import torch
import torch.nn as nn
import numpy as np
from stable_baselines3.common.torch_layers import create_mlp
from stable_baselines3.common.running_mean_std import RunningMeanStd

class RNDNetworks(nn.Module):
    '''
    Implements the Random Network Distillation (RND) networks:
    A fixed, randomly initialized target network and a trainable predictor network.
    Both are typically MLPs.
    '''
    def __init__(self, input_dim: int, output_dim: int = 128, net_arch = None, activation_fn = nn.ReLU):
        '''
        :param input_dim: Dimension of the input (observation dimension).
        :param output_dim: Dimension of the embedding output by the networks.
        :param net_arch: Architecture for the predictor and target networks (e.g., [256, 256]).
                         If None, a default [64, 64] is used.
        :param activation_fn: Activation function.
        '''
        super().__init__()

        if net_arch is None:
            net_arch = [64, 64] # Simple default architecture

        # Define Target Network (fixed random weights)
        target_layers = create_mlp(input_dim, output_dim, net_arch, activation_fn)
        self.target_network = nn.Sequential(*target_layers)

        # Define Predictor Network (trainable)
        predictor_layers = create_mlp(input_dim, output_dim, net_arch, activation_fn)
        self.predictor_network = nn.Sequential(*predictor_layers)

        # Freeze target network parameters
        for param in self.target_network.parameters():
            param.requires_grad = False

    def forward(self, next_obs: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        '''
        Pass the next observation through both networks.
        :param next_obs: The next observation tensor.
        :return: Tuple of (target_features, predictor_features).
        '''
        next_obs = next_obs.to(next(self.predictor_network.parameters()).device)
        target_features = self.target_network(next_obs)
        predictor_features = self.predictor_network(next_obs)
        return target_features, predictor_features

    def compute_loss(self, next_obs: torch.Tensor) -> torch.Tensor:
        '''
        Computes the RND prediction loss (MSE between target and predictor) per sample.
        :param next_obs: The next observation tensor.
        :return: The prediction loss per sample in the batch.
        '''
        target_features, predictor_features = self.forward(next_obs)
        loss = torch.mean(torch.square(predictor_features - target_features.detach()), dim=1)
        return loss


class RNDRewardNormalizer:
    # Normalizes intrinsic rewards using running mean and standard deviation of returns
    def __init__(self, num_envs: int, gamma: float, epsilon: float = 1e-8):
        self.epsilon = epsilon
        self.gamma = gamma
        self.num_envs = num_envs
        self.rms = RunningMeanStd(shape=(1,))
        self.returns = np.zeros(self.num_envs)

    def __call__(self, intrinsic_reward: np.ndarray) -> np.ndarray:
        # Update returns, update RMS, normalize reward
        if intrinsic_reward.shape != (self.num_envs,):
            intrinsic_reward = np.array(intrinsic_reward).reshape(self.num_envs)

        self.returns = self.returns * self.gamma + intrinsic_reward
        self.rms.update(self.returns.reshape(-1, 1))
        normalized_reward = intrinsic_reward / np.sqrt(self.rms.var[0] + self.epsilon)
        return normalized_reward

    def reset(self, dones: np.ndarray):
        # Reset returns for environments that are done
        self.returns[dones] = 0


class RNDObservationNormalizer(nn.Module):
    # Normalizes observations using running mean and standard deviation
    def __init__(self, input_shape, epsilon=1e-8, clip_obs=10.0):
        super().__init__()
        self.epsilon = epsilon
        self.clip_obs = clip_obs
        if isinstance(input_shape, int):
            input_shape = (input_shape,)
        self.rms = RunningMeanStd(shape=input_shape)
        self.register_buffer("running_mean", torch.zeros(input_shape), persistent=True)
        self.register_buffer("running_var", torch.ones(input_shape), persistent=True)
        self.register_buffer("count", torch.tensor(epsilon), persistent=True)

    def update_rms(self, obs_np: np.ndarray):
        # Update RMS statistics from a batch of observations (numpy)
        self.rms.update(obs_np)
        self.running_mean.copy_(torch.tensor(self.rms.mean, dtype=self.running_mean.dtype))
        self.running_var.copy_(torch.tensor(self.rms.var, dtype=self.running_var.dtype))
        self.count.copy_(torch.tensor(self.rms.count, dtype=self.count.dtype))

    def forward(self, obs: torch.Tensor, update_rms: bool = True) -> torch.Tensor:
        # Normalize observation
        if self.training and update_rms:
             self.update_rms(obs.cpu().numpy())

        normalized_obs = (obs - self.running_mean.to(obs.device)) / torch.sqrt(self.running_var.to(obs.device) + self.epsilon)
        normalized_obs = torch.clamp(normalized_obs, -self.clip_obs, self.clip_obs)
        return normalized_obs

    def load_state_dict(self, state_dict, strict=True):
        # Ensure RMS state is loaded correctly from buffers
        super().load_state_dict(state_dict, strict)
        self.rms.mean = self.running_mean.cpu().numpy()
        self.rms.var = self.running_var.cpu().numpy()
        self.rms.count = max(self.epsilon, self.count.item())

    @property
    def n_features(self):
        return self.rms.mean.shape[0]

if __name__ == '__main__':
    # Example usage
    obs_dim = 10
    num_envs = 4
    batch_size = num_envs

    dummy_obs_tensor = torch.randn(batch_size, obs_dim)
    dummy_next_obs_tensor = torch.randn(batch_size, obs_dim)

    print("--- Testing Observation Normalizer ---") # Removed 

    obs_norm = RNDObservationNormalizer(input_shape=(obs_dim,))
    obs_norm.train()
    normalized_obs = obs_norm(dummy_obs_tensor)
    print(f"Original Obs Mean (Batch 0): {dummy_obs_tensor[0].mean().item():.4f}, Std: {dummy_obs_tensor[0].std().item():.4f}")
    print(f"Normalized Obs Mean (Batch 0): {normalized_obs[0].mean().item():.4f}, Std: {normalized_obs[0].std().item():.4f}")
    print(f"RMS Mean after update: {obs_norm.rms.mean[:5]}...")
    obs_norm.eval()
    normalized_obs_eval = obs_norm(dummy_obs_tensor)
    print(f"Normalized Obs Mean (Eval, Batch 0): {normalized_obs_eval[0].mean().item():.4f}, Std: {normalized_obs_eval[0].std().item():.4f}")

    print("--- Testing RND Networks ---") # Removed 

    rnd_nets = RNDNetworks(input_dim=obs_dim, output_dim=64, net_arch=[128, 128])
    obs_norm.eval()
    normalized_next_obs = obs_norm(dummy_next_obs_tensor, update_rms=False)
    rnd_loss_per_sample = rnd_nets.compute_loss(normalized_next_obs)
    print(f"RND Loss per sample shape: {rnd_loss_per_sample.shape}")
    total_loss = rnd_loss_per_sample.mean()
    print(f"Total RND Loss: {total_loss.item():.4f}")

    print("--- Testing Reward Normalizer ---") # Removed 

    reward_norm = RNDRewardNormalizer(num_envs=num_envs, gamma=0.99)
    dummy_intrinsic_rewards_np = rnd_loss_per_sample.detach().cpu().numpy()
    print(f"Original Rewards: {dummy_intrinsic_rewards_np}")
    norm_r = reward_norm(dummy_intrinsic_rewards_np)
    print(f"Normalized Rewards: {norm_r} (RMS Var: {reward_norm.rms.var[0]:.4f}, Count: {reward_norm.rms.count:.1f})")
    dones = np.array([False, True, False, True])
    reward_norm.reset(dones)
    print(f"Returns after reset (dones={dones}): {reward_norm.returns}")
